var group__rot =
[
    [ "blas::rot", "group__rot.html#gaa43b200571772795705eabb9bdc1d8c1", null ],
    [ "blas::rot", "group__rot.html#ga48b1c2c9666497687ff375cf73eb7611", null ],
    [ "blas::rot", "group__rot.html#ga438ef9c353b8f3208d8368125aee2235", null ],
    [ "blas::rot", "group__rot.html#ga4208a42b2f3f4b2b89a3e976f127a387", null ],
    [ "blas::rot", "group__rot.html#ga417fcd5a61116e411b6c08691be37255", null ],
    [ "blas::rot", "group__rot.html#ga84aa73535d9a3201ca73c6c28f2cc202", null ],
    [ "blas::rot", "group__rot.html#ga47bb4a344eb3863be0587cd796a23922", null ],
    [ "blas::rot", "group__rot.html#gab63285f681ef5d0f32bb56483aa1c268", null ],
    [ "blas::rot", "group__rot.html#ga91f524e4c0870b801de26ed2dc7c2a19", null ],
    [ "blas::rot", "group__rot.html#gaf49066119dce2f164bb7ce7834a555e2", null ],
    [ "blas::rot", "group__rot.html#ga94bef871c50a7ec6c6bbcae33f7fd147", null ]
];