var group__syr2__internal =
[
    [ "blas::impl::syr2", "group__syr2__internal.html#ga64b5c8a13fd3a71cbe78852ad0c27515", null ],
    [ "blas::internal::syr2", "group__syr2__internal.html#ga27dc6c9671b61f36f3d25d7217090a37", null ],
    [ "blas::internal::syr2", "group__syr2__internal.html#gac12b567e7ade3ca398c68e2e5973133e", null ]
];