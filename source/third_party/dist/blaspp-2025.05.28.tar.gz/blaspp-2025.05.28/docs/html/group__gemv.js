var group__gemv =
[
    [ "blas::gemv", "group__gemv.html#gaab986dc4c9db314f88e1f1e7ed49e93f", null ],
    [ "blas::gemv", "group__gemv.html#ga2c0890277e2b1046cf2aeaf9a82e87b3", null ],
    [ "blas::gemv", "group__gemv.html#ga4cd7b38792b396a9fb41eec73aa09c55", null ],
    [ "blas::gemv", "group__gemv.html#gaac8c00c77b5eed816819ae5e51973876", null ],
    [ "blas::gemv", "group__gemv.html#gaad336ff5f962cb08120ad6e27bba9e89", null ]
];