var group__rotg =
[
    [ "blas::rotg", "group__rotg.html#gaf8e7b7867ab37782367c0d5641a7291d", null ],
    [ "blas::rotg", "group__rotg.html#ga6892ffe3493ebc0266fb7f7c6d3dafd2", null ],
    [ "blas::rotg", "group__rotg.html#ga5a505e5209717c95161f08a7b58469eb", null ],
    [ "blas::rotg", "group__rotg.html#ga8c1d45fe142599414a37048441a09e01", null ],
    [ "blas::rotg", "group__rotg.html#ga8dcd28a4996edaa23699d1c9efed5771", null ],
    [ "blas::rotg", "group__rotg.html#gad63ec429dcc16db2aed7891db1eeabc8", null ]
];