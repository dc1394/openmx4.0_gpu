var group__syr2 =
[
    [ "blas::syr2", "group__syr2.html#gae40bec7bbef27a34e78051a39551a917", null ],
    [ "blas::syr2", "group__syr2.html#ga0adc48786eb7452574412c0e01d979d5", null ],
    [ "blas::syr2", "group__syr2.html#ga3390d9dda4a339929e835ae2ab3ec727", null ],
    [ "blas::syr2", "group__syr2.html#ga352a7aa80810f4c0da790c7a0be4554c", null ],
    [ "blas::syr2", "group__syr2.html#gafe7a2f27af77471d339c80e991b2d237", null ]
];