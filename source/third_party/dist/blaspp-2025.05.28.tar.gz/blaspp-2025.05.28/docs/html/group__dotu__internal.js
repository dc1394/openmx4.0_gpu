var group__dotu__internal =
[
    [ "blas::impl::dotu", "group__dotu__internal.html#ga28a1bc66b606c47231f469cf9844224e", null ],
    [ "blas::impl::dotu", "group__dotu__internal.html#gaceca3f23487d03f79d2f094df44df5a7", null ],
    [ "blas::internal::dotu", "group__dotu__internal.html#gaca571c8f168f5d9424ca1c3a0a5409f2", null ],
    [ "blas::internal::dotu", "group__dotu__internal.html#ga9df3f576222fd9981a49ccb3933d55c6", null ]
];