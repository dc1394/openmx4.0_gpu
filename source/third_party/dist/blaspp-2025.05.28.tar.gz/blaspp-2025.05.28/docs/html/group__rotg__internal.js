var group__rotg__internal =
[
    [ "blas::impl::rotg", "group__rotg__internal.html#gaa5195b9e57187aa777bff80bdea604c9", null ]
];