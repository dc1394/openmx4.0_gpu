var group__rotm__internal =
[
    [ "blas::impl::rotm", "group__rotm__internal.html#ga5efdb8df68686b1caeca7e4412b920c7", null ]
];