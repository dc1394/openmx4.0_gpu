var group__ger__internal =
[
    [ "blas::impl::ger", "group__ger__internal.html#gaf70f45073358101b925aeb39fd17e111", null ],
    [ "blas::internal::ger", "group__ger__internal.html#gacc6c85a72eec5bbd5181b19e731e6236", null ],
    [ "blas::internal::ger", "group__ger__internal.html#gaa003804eed178361377446d27b91f2d0", null ]
];