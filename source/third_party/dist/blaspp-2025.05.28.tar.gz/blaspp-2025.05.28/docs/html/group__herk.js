var group__herk =
[
    [ "blas::batch::herk", "group__herk.html#ga4042ae41d1860ae87b0c0fa1a7b85116", null ],
    [ "blas::batch::herk", "group__herk.html#gac0f59bbe94887481b50d8031c8890066", null ],
    [ "blas::batch::herk", "group__herk.html#ga04a298db201295ba6afec86e75477899", null ],
    [ "blas::batch::herk", "group__herk.html#gaa48e26fba2588b6ae5395eb6744122d2", null ],
    [ "blas::batch::herk", "group__herk.html#gac1df1ab88589ac45ebb964cfb411ae70", null ],
    [ "blas::batch::herk", "group__herk.html#ga867b91d9addb8443aa5e8e1261006309", null ],
    [ "blas::batch::herk", "group__herk.html#gab735e1db5eb943cc4b80675cb06b865a", null ],
    [ "blas::batch::herk", "group__herk.html#ga20aa021c97b4d72229ecb97674f731b6", null ],
    [ "blas::herk", "group__herk.html#ga054418f1f4964ea59ec00f7223d9c221", null ],
    [ "blas::herk", "group__herk.html#ga3ab89ff25dedff65902d807e86fded4e", null ],
    [ "blas::herk", "group__herk.html#gacf2cd9b63cefe20a6371e8dd0bedc0a3", null ],
    [ "blas::herk", "group__herk.html#ga5a0c62a2704cf49b96426cbb9b54e737", null ],
    [ "blas::herk", "group__herk.html#ga0e4dcaa4440ecf1d8ba048907f6d1783", null ],
    [ "blas::herk", "group__herk.html#gacb97f2466cb72f090220c1d5452ccf62", null ],
    [ "blas::herk", "group__herk.html#gad864deca3a31ea8ccbd98fb9be03fd93", null ],
    [ "blas::herk", "group__herk.html#ga9bcf858cb1a1ceb951bfeeb7d75e1791", null ],
    [ "blas::herk", "group__herk.html#gad72e7e9d0c724ac37e0b286b50501ce3", null ]
];