var group__rotmg =
[
    [ "blas::rotmg", "group__rotmg.html#ga9605ce7d991c9818cd8b8eb29afd4f08", null ],
    [ "blas::rotmg", "group__rotmg.html#ga32e739b5fbfb2686a1c1ceb199b7303d", null ],
    [ "blas::rotmg", "group__rotmg.html#ga8335ebf701efc68844d31d85c0b025f2", null ]
];