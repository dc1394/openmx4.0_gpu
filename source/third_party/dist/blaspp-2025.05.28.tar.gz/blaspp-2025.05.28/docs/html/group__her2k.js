var group__her2k =
[
    [ "blas::batch::her2k", "group__her2k.html#ga2f47e635e53bb2ee532bc9c5e8f3974e", null ],
    [ "blas::batch::her2k", "group__her2k.html#ga14e777c2fe87cafcf7220ae09d57dc4b", null ],
    [ "blas::batch::her2k", "group__her2k.html#ga742e046bca74468d1f7dd7ee22c57356", null ],
    [ "blas::batch::her2k", "group__her2k.html#ga083e3feae3919576e65ea421a2445eec", null ],
    [ "blas::batch::her2k", "group__her2k.html#gaaa1d6cd03082ae4c9b2e0155f56e2ef7", null ],
    [ "blas::batch::her2k", "group__her2k.html#gaac1e267967786b57b024b39a5f93db17", null ],
    [ "blas::her2k", "group__her2k.html#ga7ead69b1a4a0ace6dfb8a32af2111211", null ],
    [ "blas::her2k", "group__her2k.html#gaff7ced19eec67b076414efc918b69be3", null ],
    [ "blas::her2k", "group__her2k.html#ga6d4574c3c8f246dc2ce055f89ab04a0f", null ],
    [ "blas::her2k", "group__her2k.html#gadb28d5df419a968a0afa8a3af4d0ae27", null ],
    [ "blas::her2k", "group__her2k.html#ga81e136b3d3bd849c967f10b50693ea85", null ],
    [ "blas::her2k", "group__her2k.html#ga7264af241e7b558c45c6fca255c581cf", null ],
    [ "blas::her2k", "group__her2k.html#ga085b409ed13334ff069382c3679a81a2", null ],
    [ "blas::her2k", "group__her2k.html#ga1ef2814d737642a35ad285a982484d9c", null ],
    [ "blas::her2k", "group__her2k.html#gac421ebecf1b422c827fbeb55f625caa1", null ]
];