var group__rotmg__internal =
[
    [ "blas::impl::rotmg", "group__rotmg__internal.html#ga676c303dae8e54160d7293be9b071f8c", null ]
];