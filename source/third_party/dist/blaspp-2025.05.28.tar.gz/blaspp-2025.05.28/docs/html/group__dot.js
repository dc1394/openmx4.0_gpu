var group__dot =
[
    [ "blas::dot", "group__dot.html#ga3d5f2dbeec588d39cc8569b8402accf6", null ],
    [ "blas::dot", "group__dot.html#gab2c94512cf15ef971016af9e2a9ca765", null ],
    [ "blas::dot", "group__dot.html#ga2b945bccdff779f034de8cacb696cea8", null ],
    [ "blas::dot", "group__dot.html#gab7da03ecd2ce62058c6e2a45d919ed63", null ],
    [ "blas::dot", "group__dot.html#ga71db24515d0881a7d18ba3987a6aec36", null ],
    [ "blas::dot", "group__dot.html#ga4e38fa094479e9b43cea3e6c5ad33696", null ],
    [ "blas::dot", "group__dot.html#ga452b49b99dde9a82f4e63f76aa34abe7", null ],
    [ "blas::dot", "group__dot.html#ga8a49ba14c006264dfa933dbeb1ec4885", null ],
    [ "blas::dot", "group__dot.html#ga5405cdd99ef9f89879a3b8b818823bca", null ]
];