var group__dot__internal =
[
    [ "blas::impl::dot", "group__dot__internal.html#ga125e60c1eccba115b960b14a200a7433", null ],
    [ "blas::impl::dot", "group__dot__internal.html#gaf1a45c5f438f66ac59b80ae662673771", null ],
    [ "blas::internal::dot", "group__dot__internal.html#gac9a83b90e4af8ad6bdd05bf8f440b188", null ],
    [ "blas::internal::dot", "group__dot__internal.html#ga92a14c4ce18b734825fac6d1cf40f57d", null ],
    [ "blas::internal::dot", "group__dot__internal.html#gabb4cfef5f6ac7f81d72d0001d4dac814", null ],
    [ "blas::internal::dot", "group__dot__internal.html#ga3633c3baac20e3367ac3796216be67c2", null ]
];