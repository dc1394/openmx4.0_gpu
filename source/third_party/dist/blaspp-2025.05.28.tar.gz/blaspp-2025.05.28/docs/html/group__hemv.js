var group__hemv =
[
    [ "blas::hemv", "group__hemv.html#ga7301569421b5501341024902ec45543d", null ],
    [ "blas::hemv", "group__hemv.html#ga59d4b19efb7cdcd7ccff9d5521d1c47e", null ],
    [ "blas::hemv", "group__hemv.html#gaf0df9e8d19a8934b70757abb70f29a6a", null ],
    [ "blas::hemv", "group__hemv.html#gaf895ea7174ed3e424be3f8a6a78e4537", null ],
    [ "blas::hemv", "group__hemv.html#gafc6c411d098512848e16c38b61a95e42", null ]
];