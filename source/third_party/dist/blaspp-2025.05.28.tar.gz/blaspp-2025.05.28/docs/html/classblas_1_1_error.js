var classblas_1_1_error =
[
    [ "Error", "classblas_1_1_error.html#aba32ddca18ae3220107812fa94562cc7", null ],
    [ "Error", "classblas_1_1_error.html#a4b6a466c88d6f5d2148970674f3e5d06", null ],
    [ "Error", "classblas_1_1_error.html#a8af88989035cbe66e8c2fb70e59236a2", null ],
    [ "what", "classblas_1_1_error.html#ab4dc32d8f8de74851b4b4c26226a1339", null ]
];