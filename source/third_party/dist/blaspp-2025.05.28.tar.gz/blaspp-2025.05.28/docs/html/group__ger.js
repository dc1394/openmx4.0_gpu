var group__ger =
[
    [ "blas::ger", "group__ger.html#gae73ac386941f86fbdfdee75436e8022f", null ],
    [ "blas::ger", "group__ger.html#ga51aed41f79c2d03685fdb0d2627b8ddb", null ],
    [ "blas::ger", "group__ger.html#gab692dc7debdcf01ca32b57ce941f32af", null ],
    [ "blas::ger", "group__ger.html#ga063db550893e47a4e1bd3b874c5aa22c", null ],
    [ "blas::ger", "group__ger.html#ga702b840a0138c19cb0ef966074a78429", null ]
];