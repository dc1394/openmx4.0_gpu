var group__her2__internal =
[
    [ "blas::impl::her2", "group__her2__internal.html#gaebf60d3681024a12a282f41ff4efc6e1", null ],
    [ "blas::internal::her2", "group__her2__internal.html#gad8bd6e92a85dd056db0bd22331bb9fda", null ],
    [ "blas::internal::her2", "group__her2__internal.html#gacc0ea7a67f96b9fbdcd7f050a9418241", null ]
];