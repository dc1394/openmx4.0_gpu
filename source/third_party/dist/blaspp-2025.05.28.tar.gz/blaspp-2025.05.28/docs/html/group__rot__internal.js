var group__rot__internal =
[
    [ "blas::impl::rot", "group__rot__internal.html#ga45c6702c174ecb0773d44ee9f8ef378c", null ]
];