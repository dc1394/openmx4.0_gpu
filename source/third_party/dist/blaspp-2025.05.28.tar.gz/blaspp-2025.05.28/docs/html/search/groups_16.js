var searchData=
[
  ['work_0',['work',['../group__blas1.html',1,'Level 1: vectors operations, O(n) work'],['../group__blas2.html',1,'Level 2: matrix-vector operations, O(n^2) work'],['../group__blas3.html',1,'Level 3: matrix-matrix operations, O(n^3) work']]]
];
