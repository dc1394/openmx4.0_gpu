var searchData=
[
  ['2_20norm_0',['2 norm',['../group__nrm2__internal.html',1,'nrm2:   Vector 2 norm'],['../group__nrm2.html',1,'nrm2:  Vector 2 norm']]],
  ['2_20update_1',['2 update',['../group__her2.html',1,'her2:    Hermitian rank 2 update'],['../group__her2__internal.html',1,'her2:   Hermitian rank 2 update'],['../group__syr2.html',1,'syr2:    Symmetric rank 2 update'],['../group__syr2__internal.html',1,'syr2:   Symmetric rank 2 update']]],
  ['2_20work_2',['Level 2: matrix-vector operations, O(n^2) work',['../group__blas2.html',1,'']]],
  ['2_3a_20internal_20routines_3',['Level 2: internal routines.',['../group__blas2__internal.html',1,'']]],
  ['2_3a_20matrix_20vector_20operations_20o_20n_202_20work_4',['Level 2: matrix-vector operations, O(n^2) work',['../group__blas2.html',1,'']]],
  ['2k_20update_5',['2k update',['../group__her2k__internal.html',1,'her2k:  Hermitian rank 2k update'],['../group__her2k.html',1,'her2k: Hermitian rank 2k update'],['../group__syr2k__internal.html',1,'syr2k:  Symmetric rank 2k update'],['../group__syr2k.html',1,'syr2k: Symmetric rank 2k update']]]
];
