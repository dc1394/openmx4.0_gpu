var searchData=
[
  ['what_0',['what',['../classblas_1_1_error.html#ab4dc32d8f8de74851b4b4c26226a1339',1,'blas::Error']]],
  ['work_1',['work',['../group__blas1.html',1,'Level 1: vectors operations, O(n) work'],['../group__blas2.html',1,'Level 2: matrix-vector operations, O(n^2) work'],['../group__blas3.html',1,'Level 3: matrix-matrix operations, O(n^3) work'],['../classblas_1_1_queue.html#aaf4507e38a75ef3d020851b9a47d60bd',1,'blas::Queue::work()']]],
  ['work_5fensure_5fsize_2',['work_ensure_size',['../classblas_1_1_queue.html#a153ac1c3fc04655940ea6ffc68bbd588',1,'blas::Queue']]],
  ['work_5fsize_3',['work_size',['../classblas_1_1_queue.html#ae06d19d4c7434eb238e74652f84ac4d8',1,'blas::Queue']]]
];
