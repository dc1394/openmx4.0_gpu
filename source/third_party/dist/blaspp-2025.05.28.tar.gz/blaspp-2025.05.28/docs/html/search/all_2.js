var searchData=
[
  ['3_20work_0',['Level 3: matrix-matrix operations, O(n^3) work',['../group__blas3.html',1,'']]],
  ['3_3a_20internal_20routines_1',['Level 3: internal routines.',['../group__blas3__internal.html',1,'']]],
  ['3_3a_20matrix_20matrix_20operations_20o_20n_203_20work_2',['Level 3: matrix-matrix operations, O(n^3) work',['../group__blas3.html',1,'']]]
];
