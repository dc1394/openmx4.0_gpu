var searchData=
[
  ['element_0',['element',['../group__iamax__internal.html',1,'iamax:  Find max element'],['../group__iamax.html',1,'iamax: Find max element']]]
];
