var searchData=
[
  ['scal_3a_20scale_20vector_0',['scal: Scale vector',['../group__scal__internal.html',1,'scal:   Scale vector'],['../group__scal.html',1,'scal:  Scale vector']]],
  ['scale_20vector_1',['Scale vector',['../group__scal__internal.html',1,'scal:   Scale vector'],['../group__scal.html',1,'scal:  Scale vector']]],
  ['solve_2',['solve',['../group__trsv.html',1,'trsv:       Triangular matrix-vector solve'],['../group__trsv__internal.html',1,'trsv:   Triangular matrix-vector solve']]],
  ['solve_20matrix_3',['solve matrix',['../group__trsm__internal.html',1,'trsm:   Triangular solve matrix'],['../group__trsm.html',1,'trsm:  Triangular solve matrix']]],
  ['sum_4',['sum',['../group__asum__internal.html',1,'asum:   Vector 1 norm (sum)'],['../group__asum.html',1,'asum:  Vector 1 norm (sum)']]],
  ['swap_20vectors_5',['Swap vectors',['../group__swap__internal.html',1,'swap:   Swap vectors'],['../group__swap.html',1,'swap:  Swap vectors']]],
  ['swap_3a_20swap_20vectors_6',['swap: Swap vectors',['../group__swap__internal.html',1,'swap:   Swap vectors'],['../group__swap.html',1,'swap:  Swap vectors']]],
  ['symm_3a_20symmetric_20matrix_20multiply_7',['symm: Symmetric matrix multiply',['../group__symm__internal.html',1,'symm:   Symmetric matrix multiply'],['../group__symm.html',1,'symm:  Symmetric matrix multiply']]],
  ['symmetric_20matrix_20multiply_8',['Symmetric matrix multiply',['../group__symm__internal.html',1,'symm:   Symmetric matrix multiply'],['../group__symm.html',1,'symm:  Symmetric matrix multiply']]],
  ['symmetric_20matrix_20vector_20multiply_9',['Symmetric matrix vector multiply',['../group__symv.html',1,'symv:    Symmetric matrix-vector multiply'],['../group__symv__internal.html',1,'symv:   Symmetric matrix-vector multiply']]],
  ['symmetric_20rank_201_20update_10',['Symmetric rank 1 update',['../group__syr.html',1,'syr:     Symmetric rank 1 update'],['../group__syr__internal.html',1,'syr:    Symmetric rank 1 update']]],
  ['symmetric_20rank_202_20update_11',['Symmetric rank 2 update',['../group__syr2.html',1,'syr2:    Symmetric rank 2 update'],['../group__syr2__internal.html',1,'syr2:   Symmetric rank 2 update']]],
  ['symmetric_20rank_202k_20update_12',['Symmetric rank 2k update',['../group__syr2k__internal.html',1,'syr2k:  Symmetric rank 2k update'],['../group__syr2k.html',1,'syr2k: Symmetric rank 2k update']]],
  ['symmetric_20rank_20k_20update_13',['Symmetric rank k update',['../group__syrk__internal.html',1,'syrk:   Symmetric rank k update'],['../group__syrk.html',1,'syrk:  Symmetric rank k update']]],
  ['symv_3a_20symmetric_20matrix_20vector_20multiply_14',['symv: Symmetric matrix vector multiply',['../group__symv.html',1,'symv:    Symmetric matrix-vector multiply'],['../group__symv__internal.html',1,'symv:   Symmetric matrix-vector multiply']]],
  ['syr2_3a_20symmetric_20rank_202_20update_15',['syr2: Symmetric rank 2 update',['../group__syr2.html',1,'syr2:    Symmetric rank 2 update'],['../group__syr2__internal.html',1,'syr2:   Symmetric rank 2 update']]],
  ['syr2k_3a_20symmetric_20rank_202k_20update_16',['syr2k: Symmetric rank 2k update',['../group__syr2k__internal.html',1,'syr2k:  Symmetric rank 2k update'],['../group__syr2k.html',1,'syr2k: Symmetric rank 2k update']]],
  ['syr_3a_20symmetric_20rank_201_20update_17',['syr: Symmetric rank 1 update',['../group__syr.html',1,'syr:     Symmetric rank 1 update'],['../group__syr__internal.html',1,'syr:    Symmetric rank 1 update']]],
  ['syrk_3a_20symmetric_20rank_20k_20update_18',['syrk: Symmetric rank k update',['../group__syrk__internal.html',1,'syrk:   Symmetric rank k update'],['../group__syrk.html',1,'syrk:  Symmetric rank k update']]]
];
