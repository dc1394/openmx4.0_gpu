var indexSectionsWithContent =
{
  0: "123abcdefghijklmnopqrstuvw",
  1: "ceiq",
  2: "acdefghijnpqrstw",
  3: "i",
  4: "123acdefghiklmnoprstuvw",
  5: "bin"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "enums",
  4: "groups",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Enumerations",
  4: "Modules",
  5: "Pages"
};

