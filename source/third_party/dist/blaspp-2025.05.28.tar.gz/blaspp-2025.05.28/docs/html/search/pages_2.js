var searchData=
[
  ['notes_0',['BLAS++ Installation Notes',['../md__i_n_s_t_a_l_l.html',1,'']]]
];
