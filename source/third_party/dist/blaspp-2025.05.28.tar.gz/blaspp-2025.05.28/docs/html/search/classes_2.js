var searchData=
[
  ['is_5fcomplex_0',['is_complex',['../structblas_1_1is__complex.html',1,'blas']]]
];
