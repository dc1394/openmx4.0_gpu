var searchData=
[
  ['variables_20makefile_20and_20cmake_0',['Environment variables (Makefile and CMake)',['../md__i_n_s_t_a_l_l.html#autotoc_md14',1,'']]],
  ['vector_1',['vector',['../group__copy__internal.html',1,'copy:   Copy vector'],['../group__copy.html',1,'copy:  Copy vector'],['../group__scal__internal.html',1,'scal:   Scale vector'],['../group__scal.html',1,'scal:  Scale vector']]],
  ['vector_201_20norm_20sum_2',['Vector 1 norm sum',['../group__asum__internal.html',1,'asum:   Vector 1 norm (sum)'],['../group__asum.html',1,'asum:  Vector 1 norm (sum)']]],
  ['vector_202_20norm_3',['Vector 2 norm',['../group__nrm2__internal.html',1,'nrm2:   Vector 2 norm'],['../group__nrm2.html',1,'nrm2:  Vector 2 norm']]],
  ['vector_20multiply_4',['vector multiply',['../group__gemv.html',1,'gemv:       General matrix-vector multiply'],['../group__gemv__internal.html',1,'gemv:   General matrix-vector multiply'],['../group__hemv.html',1,'hemv:    Hermitian matrix-vector multiply'],['../group__hemv__internal.html',1,'hemv:   Hermitian matrix-vector multiply'],['../group__symv.html',1,'symv:    Symmetric matrix-vector multiply'],['../group__symv__internal.html',1,'symv:   Symmetric matrix-vector multiply'],['../group__trmv.html',1,'trmv:       Triangular matrix-vector multiply'],['../group__trmv__internal.html',1,'trmv:   Triangular matrix-vector multiply']]],
  ['vector_20operations_20o_20n_202_20work_5',['Level 2: matrix-vector operations, O(n^2) work',['../group__blas2.html',1,'']]],
  ['vector_20solve_6',['vector solve',['../group__trsv.html',1,'trsv:       Triangular matrix-vector solve'],['../group__trsv__internal.html',1,'trsv:   Triangular matrix-vector solve']]],
  ['vectors_7',['vectors',['../group__axpy__internal.html',1,'axpy:   Add vectors'],['../group__axpy.html',1,'axpy:  Add vectors'],['../group__swap__internal.html',1,'swap:   Swap vectors'],['../group__swap.html',1,'swap:  Swap vectors']]],
  ['vectors_20operations_20o_20n_20work_8',['Level 1: vectors operations, O(n) work',['../group__blas1.html',1,'']]],
  ['vendor_20notes_9',['Vendor notes',['../md__i_n_s_t_a_l_l.html#autotoc_md18',1,'']]]
];
