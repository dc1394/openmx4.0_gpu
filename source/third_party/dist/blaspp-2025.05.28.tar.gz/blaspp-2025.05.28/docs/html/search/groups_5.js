var searchData=
[
  ['dot_20inner_20product_0',['Dot inner product',['../group__dot__internal.html',1,'dot:    Dot (inner) product'],['../group__dot.html',1,'dot:   Dot (inner) product']]],
  ['dot_20inner_20product_20unconjugated_1',['Dot inner product unconjugated',['../group__dotu__internal.html',1,'dotu:   Dot (inner) product, unconjugated'],['../group__dotu.html',1,'dotu:  Dot (inner) product, unconjugated']]],
  ['dot_3a_20dot_20inner_20product_2',['dot: Dot inner product',['../group__dot__internal.html',1,'dot:    Dot (inner) product'],['../group__dot.html',1,'dot:   Dot (inner) product']]],
  ['dotu_3a_20dot_20inner_20product_20unconjugated_3',['dotu: Dot inner product unconjugated',['../group__dotu__internal.html',1,'dotu:   Dot (inner) product, unconjugated'],['../group__dotu.html',1,'dotu:  Dot (inner) product, unconjugated']]]
];
