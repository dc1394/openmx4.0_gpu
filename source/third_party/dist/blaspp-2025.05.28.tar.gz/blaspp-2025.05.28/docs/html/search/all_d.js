var searchData=
[
  ['k_20update_0',['k update',['../group__herk__internal.html',1,'herk:   Hermitian rank k update'],['../group__herk.html',1,'herk:  Hermitian rank k update'],['../group__syrk__internal.html',1,'syrk:   Symmetric rank k update'],['../group__syrk.html',1,'syrk:  Symmetric rank k update']]]
];
