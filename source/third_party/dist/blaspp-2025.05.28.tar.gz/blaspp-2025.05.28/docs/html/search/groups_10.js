var searchData=
[
  ['plane_20rotation_0',['plane rotation',['../group__rot__internal.html',1,'rot:    Apply Givens plane rotation'],['../group__rot.html',1,'rot:   Apply Givens plane rotation'],['../group__rotg__internal.html',1,'rotg:   Generate Givens plane rotation'],['../group__rotg.html',1,'rotg:  Generate Givens plane rotation'],['../group__rotm__internal.html',1,'rotm:   Apply modified (fast) Givens plane rotation'],['../group__rotm.html',1,'rotm:  Apply modified (fast) Givens plane rotation'],['../group__rotmg__internal.html',1,'rotmg:  Generate modified (fast) Givens plane rotation'],['../group__rotmg.html',1,'rotmg: Generate modified (fast) Givens plane rotation']]],
  ['product_1',['product',['../group__dot__internal.html',1,'dot:    Dot (inner) product'],['../group__dot.html',1,'dot:   Dot (inner) product']]],
  ['product_20unconjugated_2',['product unconjugated',['../group__dotu__internal.html',1,'dotu:   Dot (inner) product, unconjugated'],['../group__dotu.html',1,'dotu:  Dot (inner) product, unconjugated']]]
];
