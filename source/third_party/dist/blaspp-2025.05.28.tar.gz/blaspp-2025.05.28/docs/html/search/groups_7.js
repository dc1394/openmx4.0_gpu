var searchData=
[
  ['fast_20givens_20plane_20rotation_0',['fast Givens plane rotation',['../group__rotm__internal.html',1,'rotm:   Apply modified (fast) Givens plane rotation'],['../group__rotm.html',1,'rotm:  Apply modified (fast) Givens plane rotation'],['../group__rotmg__internal.html',1,'rotmg:  Generate modified (fast) Givens plane rotation'],['../group__rotmg.html',1,'rotmg: Generate modified (fast) Givens plane rotation']]],
  ['find_20max_20element_1',['Find max element',['../group__iamax__internal.html',1,'iamax:  Find max element'],['../group__iamax.html',1,'iamax: Find max element']]]
];
