var searchData=
[
  ['add_20vectors_0',['Add vectors',['../group__axpy__internal.html',1,'axpy:   Add vectors'],['../group__axpy.html',1,'axpy:  Add vectors']]],
  ['apply_20givens_20plane_20rotation_1',['Apply Givens plane rotation',['../group__rot__internal.html',1,'rot:    Apply Givens plane rotation'],['../group__rot.html',1,'rot:   Apply Givens plane rotation']]],
  ['apply_20modified_20fast_20givens_20plane_20rotation_2',['Apply modified fast Givens plane rotation',['../group__rotm__internal.html',1,'rotm:   Apply modified (fast) Givens plane rotation'],['../group__rotm.html',1,'rotm:  Apply modified (fast) Givens plane rotation']]],
  ['asum_3a_20vector_201_20norm_20sum_3',['asum: Vector 1 norm sum',['../group__asum__internal.html',1,'asum:   Vector 1 norm (sum)'],['../group__asum.html',1,'asum:  Vector 1 norm (sum)']]],
  ['axpy_3a_20add_20vectors_4',['axpy: Add vectors',['../group__axpy__internal.html',1,'axpy:   Add vectors'],['../group__axpy.html',1,'axpy:  Add vectors']]]
];
