var searchData=
[
  ['queue_0',['Queue',['../classblas_1_1_queue.html#aa255766f2a9abd8172166dc029e66451',1,'blas::Queue::Queue()'],['../classblas_1_1_queue.html#a33f27f06c09576abd165b6bc826d692e',1,'blas::Queue::Queue(int device)']]]
];
