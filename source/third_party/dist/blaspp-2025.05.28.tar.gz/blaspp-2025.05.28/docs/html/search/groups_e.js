var searchData=
[
  ['n_202_20work_0',['Level 2: matrix-vector operations, O(n^2) work',['../group__blas2.html',1,'']]],
  ['n_203_20work_1',['Level 3: matrix-matrix operations, O(n^3) work',['../group__blas3.html',1,'']]],
  ['n_20work_2',['Level 1: vectors operations, O(n) work',['../group__blas1.html',1,'']]],
  ['norm_3',['norm',['../group__nrm2__internal.html',1,'nrm2:   Vector 2 norm'],['../group__nrm2.html',1,'nrm2:  Vector 2 norm']]],
  ['norm_20sum_4',['norm sum',['../group__asum__internal.html',1,'asum:   Vector 1 norm (sum)'],['../group__asum.html',1,'asum:  Vector 1 norm (sum)']]],
  ['nrm2_3a_20vector_202_20norm_5',['nrm2: Vector 2 norm',['../group__nrm2__internal.html',1,'nrm2:   Vector 2 norm'],['../group__nrm2.html',1,'nrm2:  Vector 2 norm']]]
];
