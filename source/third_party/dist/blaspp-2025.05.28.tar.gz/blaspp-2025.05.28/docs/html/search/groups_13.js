var searchData=
[
  ['triangular_20matrix_20multiply_0',['Triangular matrix multiply',['../group__trmm__internal.html',1,'trmm:   Triangular matrix multiply'],['../group__trmm.html',1,'trmm:  Triangular matrix multiply']]],
  ['triangular_20matrix_20vector_20multiply_1',['Triangular matrix vector multiply',['../group__trmv.html',1,'trmv:       Triangular matrix-vector multiply'],['../group__trmv__internal.html',1,'trmv:   Triangular matrix-vector multiply']]],
  ['triangular_20matrix_20vector_20solve_2',['Triangular matrix vector solve',['../group__trsv.html',1,'trsv:       Triangular matrix-vector solve'],['../group__trsv__internal.html',1,'trsv:   Triangular matrix-vector solve']]],
  ['triangular_20solve_20matrix_3',['Triangular solve matrix',['../group__trsm__internal.html',1,'trsm:   Triangular solve matrix'],['../group__trsm.html',1,'trsm:  Triangular solve matrix']]],
  ['trmm_3a_20triangular_20matrix_20multiply_4',['trmm: Triangular matrix multiply',['../group__trmm__internal.html',1,'trmm:   Triangular matrix multiply'],['../group__trmm.html',1,'trmm:  Triangular matrix multiply']]],
  ['trmv_3a_20triangular_20matrix_20vector_20multiply_5',['trmv: Triangular matrix vector multiply',['../group__trmv.html',1,'trmv:       Triangular matrix-vector multiply'],['../group__trmv__internal.html',1,'trmv:   Triangular matrix-vector multiply']]],
  ['trsm_3a_20triangular_20solve_20matrix_6',['trsm: Triangular solve matrix',['../group__trsm__internal.html',1,'trsm:   Triangular solve matrix'],['../group__trsm.html',1,'trsm:  Triangular solve matrix']]],
  ['trsv_3a_20triangular_20matrix_20vector_20solve_7',['trsv: Triangular matrix vector solve',['../group__trsv.html',1,'trsv:       Triangular matrix-vector solve'],['../group__trsv__internal.html',1,'trsv:   Triangular matrix-vector solve']]]
];
