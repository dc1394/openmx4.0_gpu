var searchData=
[
  ['iamax_3a_20find_20max_20element_0',['iamax: Find max element',['../group__iamax__internal.html',1,'iamax:  Find max element'],['../group__iamax.html',1,'iamax: Find max element']]],
  ['inner_20product_1',['inner product',['../group__dot__internal.html',1,'dot:    Dot (inner) product'],['../group__dot.html',1,'dot:   Dot (inner) product']]],
  ['inner_20product_20unconjugated_2',['inner product unconjugated',['../group__dotu__internal.html',1,'dotu:   Dot (inner) product, unconjugated'],['../group__dotu.html',1,'dotu:  Dot (inner) product, unconjugated']]],
  ['internal_20routines_3',['internal routines',['../group__blas1__internal.html',1,'Level 1: internal routines.'],['../group__blas2__internal.html',1,'Level 2: internal routines.'],['../group__blas3__internal.html',1,'Level 3: internal routines.']]]
];
