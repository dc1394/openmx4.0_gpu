var searchData=
[
  ['error_0',['Error',['../classblas_1_1_error.html#aba32ddca18ae3220107812fa94562cc7',1,'blas::Error::Error()'],['../classblas_1_1_error.html#a4b6a466c88d6f5d2148970674f3e5d06',1,'blas::Error::Error(std::string const &amp;msg)'],['../classblas_1_1_error.html#a8af88989035cbe66e8c2fb70e59236a2',1,'blas::Error::Error(const char *msg, const char *func)']]]
];
