var searchData=
[
  ['error_0',['Error',['../classblas_1_1_error.html',1,'blas']]]
];
