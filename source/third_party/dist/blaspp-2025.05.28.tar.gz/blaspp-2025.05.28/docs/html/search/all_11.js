var searchData=
[
  ['o_20n_202_20work_0',['Level 2: matrix-vector operations, O(n^2) work',['../group__blas2.html',1,'']]],
  ['o_20n_203_20work_1',['Level 3: matrix-matrix operations, O(n^3) work',['../group__blas3.html',1,'']]],
  ['o_20n_20work_2',['Level 1: vectors operations, O(n) work',['../group__blas1.html',1,'']]],
  ['operations_20o_20n_202_20work_3',['Level 2: matrix-vector operations, O(n^2) work',['../group__blas2.html',1,'']]],
  ['operations_20o_20n_203_20work_4',['Level 3: matrix-matrix operations, O(n^3) work',['../group__blas3.html',1,'']]],
  ['operations_20o_20n_20work_5',['Level 1: vectors operations, O(n) work',['../group__blas1.html',1,'']]],
  ['options_6',['Options',['../md__i_n_s_t_a_l_l.html#autotoc_md17',1,'Options'],['../md__i_n_s_t_a_l_l.html#autotoc_md21',1,'Options']]],
  ['options_20makefile_20and_20cmake_7',['Options (Makefile and CMake)',['../md__i_n_s_t_a_l_l.html#autotoc_md15',1,'']]]
];
