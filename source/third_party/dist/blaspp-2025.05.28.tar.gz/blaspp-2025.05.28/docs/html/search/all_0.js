var searchData=
[
  ['1_20norm_20sum_0',['1 norm sum',['../group__asum__internal.html',1,'asum:   Vector 1 norm (sum)'],['../group__asum.html',1,'asum:  Vector 1 norm (sum)']]],
  ['1_20update_1',['1 update',['../group__ger.html',1,'ger:        General matrix rank 1 update'],['../group__ger__internal.html',1,'ger:    General matrix rank 1 update'],['../group__her.html',1,'her:     Hermitian rank 1 update'],['../group__her__internal.html',1,'her:    Hermitian rank 1 update'],['../group__syr.html',1,'syr:     Symmetric rank 1 update'],['../group__syr__internal.html',1,'syr:    Symmetric rank 1 update']]],
  ['1_20update_20unconjugated_2',['1 update unconjugated',['../group__geru.html',1,'geru:       General matrix rank 1 update, unconjugated'],['../group__geru__internal.html',1,'geru:   General matrix rank 1 update, unconjugated']]],
  ['1_3a_20internal_20routines_3',['Level 1: internal routines.',['../group__blas1__internal.html',1,'']]],
  ['1_3a_20vectors_20operations_20o_20n_20work_4',['Level 1: vectors operations, O(n) work',['../group__blas1.html',1,'']]]
];
