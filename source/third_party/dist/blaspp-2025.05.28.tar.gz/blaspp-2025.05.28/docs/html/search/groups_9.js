var searchData=
[
  ['hemm_3a_20hermitian_20matrix_20multiply_0',['hemm: Hermitian matrix multiply',['../group__hemm__internal.html',1,'hemm:   Hermitian matrix multiply'],['../group__hemm.html',1,'hemm:  Hermitian matrix multiply']]],
  ['hemv_3a_20hermitian_20matrix_20vector_20multiply_1',['hemv: Hermitian matrix vector multiply',['../group__hemv.html',1,'hemv:    Hermitian matrix-vector multiply'],['../group__hemv__internal.html',1,'hemv:   Hermitian matrix-vector multiply']]],
  ['her2_3a_20hermitian_20rank_202_20update_2',['her2: Hermitian rank 2 update',['../group__her2.html',1,'her2:    Hermitian rank 2 update'],['../group__her2__internal.html',1,'her2:   Hermitian rank 2 update']]],
  ['her2k_3a_20hermitian_20rank_202k_20update_3',['her2k: Hermitian rank 2k update',['../group__her2k__internal.html',1,'her2k:  Hermitian rank 2k update'],['../group__her2k.html',1,'her2k: Hermitian rank 2k update']]],
  ['her_3a_20hermitian_20rank_201_20update_4',['her: Hermitian rank 1 update',['../group__her.html',1,'her:     Hermitian rank 1 update'],['../group__her__internal.html',1,'her:    Hermitian rank 1 update']]],
  ['herk_3a_20hermitian_20rank_20k_20update_5',['herk: Hermitian rank k update',['../group__herk__internal.html',1,'herk:   Hermitian rank k update'],['../group__herk.html',1,'herk:  Hermitian rank k update']]],
  ['hermitian_20matrix_20multiply_6',['Hermitian matrix multiply',['../group__hemm__internal.html',1,'hemm:   Hermitian matrix multiply'],['../group__hemm.html',1,'hemm:  Hermitian matrix multiply']]],
  ['hermitian_20matrix_20vector_20multiply_7',['Hermitian matrix vector multiply',['../group__hemv.html',1,'hemv:    Hermitian matrix-vector multiply'],['../group__hemv__internal.html',1,'hemv:   Hermitian matrix-vector multiply']]],
  ['hermitian_20rank_201_20update_8',['Hermitian rank 1 update',['../group__her.html',1,'her:     Hermitian rank 1 update'],['../group__her__internal.html',1,'her:    Hermitian rank 1 update']]],
  ['hermitian_20rank_202_20update_9',['Hermitian rank 2 update',['../group__her2.html',1,'her2:    Hermitian rank 2 update'],['../group__her2__internal.html',1,'her2:   Hermitian rank 2 update']]],
  ['hermitian_20rank_202k_20update_10',['Hermitian rank 2k update',['../group__her2k__internal.html',1,'her2k:  Hermitian rank 2k update'],['../group__her2k.html',1,'her2k: Hermitian rank 2k update']]],
  ['hermitian_20rank_20k_20update_11',['Hermitian rank k update',['../group__herk__internal.html',1,'herk:   Hermitian rank k update'],['../group__herk.html',1,'herk:  Hermitian rank k update']]]
];
