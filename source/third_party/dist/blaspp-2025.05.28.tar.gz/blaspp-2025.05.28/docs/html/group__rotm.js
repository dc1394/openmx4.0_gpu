var group__rotm =
[
    [ "blas::rotm", "group__rotm.html#ga9dc5e1abc7ad34cd2650ab4cadef46f1", null ],
    [ "blas::rotm", "group__rotm.html#ga9077717871565f92842fc4e2f623055c", null ],
    [ "blas::rotm", "group__rotm.html#ga943f189058899c6f0baa3b9a73b4b554", null ]
];