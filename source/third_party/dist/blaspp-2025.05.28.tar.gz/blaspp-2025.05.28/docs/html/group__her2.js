var group__her2 =
[
    [ "blas::her2", "group__her2.html#ga476efe797a17c3a23501025699cca4ba", null ],
    [ "blas::her2", "group__her2.html#ga3b47e29b5f3c775ac1f69675458352de", null ],
    [ "blas::her2", "group__her2.html#ga130ec390e14ff1f3a1149aab9ec0b45e", null ],
    [ "blas::her2", "group__her2.html#gad167cbf35d8840674767e5f47e387f8d", null ],
    [ "blas::her2", "group__her2.html#ga370c6b21c0b0a259d6c9304bbf39fa3b", null ]
];