var group__nrm2 =
[
    [ "blas::nrm2", "group__nrm2.html#gaf058f5900fe8d30df8270c702dce785c", null ],
    [ "blas::nrm2", "group__nrm2.html#ga46f91c44a1af535c40bcd7d3c3333816", null ],
    [ "blas::nrm2", "group__nrm2.html#gacf129f0b467418ec7349c9c913f2536a", null ],
    [ "blas::nrm2", "group__nrm2.html#ga79bb63aab8793e011ab3604886249de8", null ],
    [ "blas::nrm2", "group__nrm2.html#ga5ac1c4b9cd855f8893ed9b8dc420199b", null ],
    [ "blas::nrm2", "group__nrm2.html#ga3bc08aa8b1080504afcfa6c7d12b5526", null ],
    [ "blas::nrm2", "group__nrm2.html#ga031fb5acc447a2840b57744da09ca138", null ],
    [ "blas::nrm2", "group__nrm2.html#gab59c09317c6b434db28e450ab01af9d9", null ],
    [ "blas::nrm2", "group__nrm2.html#gac2becc6f665070c75aed68a9504a9773", null ]
];