var group__syr =
[
    [ "blas::syr", "group__syr.html#gaa89e99d435da42c213216f1d05fa881c", null ],
    [ "blas::syr", "group__syr.html#ga8b92484c6d31ae5c0a856370dd222cb1", null ],
    [ "blas::syr", "group__syr.html#ga50073d693888b6d63a1c2ae965dc0884", null ],
    [ "blas::syr", "group__syr.html#gad764677f1bac18bc1ba55f65161c8e24", null ],
    [ "blas::syr", "group__syr.html#ga70ca69394cc4f62e711657f42400dad4", null ]
];