var group__geru =
[
    [ "blas::geru", "group__geru.html#gab3dd6df4e909762ec211140240a76ad8", null ],
    [ "blas::geru", "group__geru.html#gae8067460ea89ca116fd3e6f849386cc9", null ],
    [ "blas::geru", "group__geru.html#ga13cb46774a26319fd69775b7d8591da0", null ],
    [ "blas::geru", "group__geru.html#gaa033606b2e235f5f54339764a03831a9", null ],
    [ "blas::geru", "group__geru.html#ga16e6b2edc0df841aa630db4b2e325688", null ]
];