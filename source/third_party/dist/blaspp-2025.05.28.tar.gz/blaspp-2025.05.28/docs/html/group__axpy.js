var group__axpy =
[
    [ "blas::axpy", "group__axpy.html#ga3e7203329dd30b2ad7e74dae751c2f71", null ],
    [ "blas::axpy", "group__axpy.html#ga192a48552f4dd8282427f36bb6ceb31c", null ],
    [ "blas::axpy", "group__axpy.html#ga33a2b1303f1e915b5885854b48bcb5db", null ],
    [ "blas::axpy", "group__axpy.html#gace9a31ef0fdc3f10c3039ef5102ec688", null ],
    [ "blas::axpy", "group__axpy.html#gab3bd07bae8c56cd076bcfb8bddad5fc0", null ],
    [ "blas::axpy", "group__axpy.html#ga2cc072a563dc207ea0835b8ad0bc01f3", null ],
    [ "blas::axpy", "group__axpy.html#gaa2ba3f158d937e572e5b98ceb2dffc74", null ],
    [ "blas::axpy", "group__axpy.html#gaf483a2dff4eb500ae65b73a1511dabf5", null ],
    [ "blas::axpy", "group__axpy.html#gad1473364edcca58f037279346d9b944f", null ]
];