var group__dotu =
[
    [ "blas::dotu", "group__dotu.html#gab7c40a15f3cf17c60320235356b7618d", null ],
    [ "blas::dotu", "group__dotu.html#gaf71f5c929b7fa63fc37f3dd439dcc2d9", null ],
    [ "blas::dotu", "group__dotu.html#gad8c4c76ef43c7b478137aaac86070b49", null ],
    [ "blas::dotu", "group__dotu.html#ga3c2eba3f7da801e65a298b2c8a7053c0", null ],
    [ "blas::dotu", "group__dotu.html#ga7d12d6680b9f3ba317385482238e6273", null ],
    [ "blas::dotu", "group__dotu.html#ga91108e37bdabb46b51206203f549bee0", null ],
    [ "blas::dotu", "group__dotu.html#ga4db939b4a4e2a1e4959b3c75cfd8e9dd", null ],
    [ "blas::dotu", "group__dotu.html#gacbc2d31c892230c35af8691496323cf3", null ],
    [ "blas::dotu", "group__dotu.html#ga30bacee59897d13ec4db38e3f42f1344", null ]
];