var annotated_dup =
[
    [ "blas", null, [
      [ "counter", "classblas_1_1counter.html", "classblas_1_1counter" ],
      [ "Error", "classblas_1_1_error.html", "classblas_1_1_error" ],
      [ "is_complex", "structblas_1_1is__complex.html", null ],
      [ "Queue", "classblas_1_1_queue.html", "classblas_1_1_queue" ]
    ] ]
];