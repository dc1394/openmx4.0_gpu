//
// Distributed Linear Algebra with Future (DLAF)
//
// Copyright (c) ETH Zurich
// All rights reserved.
//
// Please, refer to the LICENSE file in the root directory.
// SPDX-License-Identifier: BSD-3-Clause
//
#pragma once

/// @file

#include <utility>

#include <blas.hh>

#include <dlaf/eigensolver/gen_eigensolver/api.h>
#include <dlaf/matrix/matrix.h>
#include <dlaf/types.h>
#include <dlaf/util_matrix.h>

#include "gen_eigensolver/api.h"

namespace dlaf {

namespace eigensolver::internal {

template <Backend B, Device D, class T>
void hermitian_generalized_eigensolver(blas::Uplo uplo, Matrix<T, D>& mat_a, Matrix<T, D>& mat_b,
                                       Matrix<BaseType<T>, D>& eigenvalues, Matrix<T, D>& eigenvectors,
                                       const Factorization factorization,
                                       const SizeType eigenvalues_index_begin,
                                       const SizeType eigenvalues_index_end) {
  DLAF_ASSERT(matrix::local_matrix(mat_a), mat_a);
  DLAF_ASSERT(matrix::local_matrix(mat_b), mat_b);
  DLAF_ASSERT(matrix::local_matrix(eigenvalues), eigenvalues);
  DLAF_ASSERT(matrix::local_matrix(eigenvectors), eigenvectors);
  DLAF_ASSERT(matrix::square_size(mat_a), mat_a);
  DLAF_ASSERT(matrix::single_tile_per_block(mat_a), mat_a);
  DLAF_ASSERT(matrix::square_block_size(mat_a), mat_a);
  DLAF_ASSERT(matrix::square_size(mat_b), mat_b);
  DLAF_ASSERT(matrix::single_tile_per_block(mat_b), mat_b);
  DLAF_ASSERT(matrix::square_block_size(mat_b), mat_b);
  DLAF_ASSERT(mat_a.size() == mat_b.size(), mat_a, mat_b);
  DLAF_ASSERT(mat_a.block_size() == mat_b.block_size(), mat_a, mat_b);
  DLAF_ASSERT(eigenvalues.size().rows() == eigenvectors.size().rows(), eigenvalues, eigenvectors);
  DLAF_ASSERT(matrix::single_tile_per_block(eigenvalues), eigenvalues);
  DLAF_ASSERT(eigenvalues.block_size().rows() == eigenvectors.block_size().rows(), eigenvalues,
              eigenvectors);
  DLAF_ASSERT(eigenvectors.size() == mat_a.size(), eigenvectors, mat_a);
  DLAF_ASSERT(matrix::square_size(eigenvectors), eigenvectors);
  DLAF_ASSERT(matrix::single_tile_per_block(eigenvectors), eigenvectors);
  DLAF_ASSERT(matrix::square_block_size(eigenvectors), eigenvectors);
  DLAF_ASSERT(eigenvectors.block_size() == mat_a.block_size(), eigenvectors, mat_a);
  DLAF_ASSERT(eigenvalues_index_begin == 0, eigenvalues_index_begin);
  DLAF_ASSERT(eigenvalues_index_end >= eigenvalues_index_begin, eigenvalues_index_end,
              eigenvalues_index_begin);
  DLAF_ASSERT(eigenvalues_index_end <= mat_a.size().rows(), eigenvalues_index_end, mat_a.size().rows());

  eigensolver::internal::GenEigensolver<B, D, T>::call(uplo, mat_a, mat_b, eigenvalues, eigenvectors,
                                                       factorization, eigenvalues_index_begin,
                                                       eigenvalues_index_end);
}

template <Backend B, Device D, class T>
EigensolverResult<T, D> hermitian_generalized_eigensolver(
    blas::Uplo uplo, Matrix<T, D>& mat_a, Matrix<T, D>& mat_b, const Factorization factorization,
    const SizeType eigenvalues_index_begin, const SizeType eigenvalues_index_end) {
  DLAF_ASSERT(matrix::local_matrix(mat_a), mat_a);
  DLAF_ASSERT(matrix::local_matrix(mat_b), mat_b);
  DLAF_ASSERT(matrix::square_size(mat_a), mat_a);
  DLAF_ASSERT(matrix::single_tile_per_block(mat_a), mat_a);
  DLAF_ASSERT(matrix::square_block_size(mat_a), mat_a);
  DLAF_ASSERT(matrix::square_size(mat_b), mat_b);
  DLAF_ASSERT(matrix::single_tile_per_block(mat_b), mat_b);
  DLAF_ASSERT(matrix::square_block_size(mat_b), mat_b);
  DLAF_ASSERT(mat_a.size() == mat_b.size(), mat_a, mat_b);
  DLAF_ASSERT(mat_a.block_size() == mat_b.block_size(), mat_a, mat_b);
  DLAF_ASSERT(eigenvalues_index_begin == 0, eigenvalues_index_begin);
  DLAF_ASSERT(eigenvalues_index_end >= eigenvalues_index_begin, eigenvalues_index_end,
              eigenvalues_index_begin);
  DLAF_ASSERT(eigenvalues_index_end <= mat_a.size().rows(), eigenvalues_index_end, mat_a.size().rows());

  const SizeType size = mat_a.size().rows();

  matrix::Matrix<BaseType<T>, D> eigenvalues(LocalElementSize(size, 1),
                                             TileElementSize(mat_a.tile_size().rows(), 1));
  matrix::Matrix<T, D> eigenvectors(LocalElementSize(size, size), mat_a.tile_size());

  hermitian_generalized_eigensolver<B, D, T>(uplo, mat_a, mat_b, eigenvalues, eigenvectors,
                                             factorization, eigenvalues_index_begin,
                                             eigenvalues_index_end);

  return {std::move(eigenvalues), std::move(eigenvectors)};
}

template <Backend B, Device D, class T>
void hermitian_generalized_eigensolver(
    comm::CommunicatorGrid& grid, blas::Uplo uplo, Matrix<T, D>& mat_a, Matrix<T, D>& mat_b,
    Matrix<BaseType<T>, D>& eigenvalues, Matrix<T, D>& eigenvectors, const Factorization factorization,
    const SizeType eigenvalues_index_begin, const SizeType eigenvalues_index_end) {
  DLAF_ASSERT(matrix::equal_process_grid(mat_a, grid), mat_a, grid);
  DLAF_ASSERT(matrix::equal_process_grid(mat_b, grid), mat_b, grid);
  DLAF_ASSERT(matrix::local_matrix(eigenvalues), eigenvalues);
  DLAF_ASSERT(matrix::equal_process_grid(eigenvectors, grid), eigenvectors, grid);
  DLAF_ASSERT(matrix::square_size(mat_a), mat_a);
  DLAF_ASSERT(matrix::single_tile_per_block(mat_a), mat_a);
  DLAF_ASSERT(matrix::square_block_size(mat_a), mat_a);
  DLAF_ASSERT(matrix::square_size(mat_b), mat_b);
  DLAF_ASSERT(matrix::single_tile_per_block(mat_b), mat_b);
  DLAF_ASSERT(matrix::square_block_size(mat_b), mat_b);
  DLAF_ASSERT(mat_a.size() == mat_b.size(), mat_a, mat_b);
  DLAF_ASSERT(mat_a.block_size() == mat_b.block_size(), mat_a, mat_b);
  DLAF_ASSERT(eigenvalues.size().rows() == eigenvectors.size().rows(), eigenvalues, eigenvectors);
  DLAF_ASSERT(matrix::single_tile_per_block(eigenvalues), eigenvalues);
  DLAF_ASSERT(eigenvalues.block_size().rows() == eigenvectors.block_size().rows(), eigenvalues,
              eigenvectors);
  DLAF_ASSERT(eigenvectors.size() == mat_a.size(), eigenvectors, mat_a);
  DLAF_ASSERT(matrix::square_size(eigenvectors), eigenvectors);
  DLAF_ASSERT(matrix::single_tile_per_block(eigenvectors), eigenvectors);
  DLAF_ASSERT(matrix::square_block_size(eigenvectors), eigenvectors);
  DLAF_ASSERT(eigenvectors.block_size() == mat_a.block_size(), eigenvectors, mat_a);
  DLAF_ASSERT(eigenvalues_index_begin == 0, eigenvalues_index_begin);
  DLAF_ASSERT(eigenvalues_index_end >= eigenvalues_index_begin, eigenvalues_index_end,
              eigenvalues_index_begin);
  DLAF_ASSERT(eigenvalues_index_end <= mat_a.size().rows(), eigenvalues_index_end, mat_a.size().rows());

  eigensolver::internal::GenEigensolver<B, D, T>::call(grid, uplo, mat_a, mat_b, eigenvalues,
                                                       eigenvectors, factorization,
                                                       eigenvalues_index_begin, eigenvalues_index_end);
}

template <Backend B, Device D, class T>
EigensolverResult<T, D> hermitian_generalized_eigensolver(comm::CommunicatorGrid& grid, blas::Uplo uplo,
                                                          Matrix<T, D>& mat_a, Matrix<T, D>& mat_b,
                                                          const Factorization factorization,
                                                          const SizeType eigenvalues_index_begin,
                                                          const SizeType eigenvalues_index_end) {
  DLAF_ASSERT(matrix::equal_process_grid(mat_a, grid), mat_a, grid);
  DLAF_ASSERT(matrix::equal_process_grid(mat_b, grid), mat_b, grid);
  DLAF_ASSERT(matrix::square_size(mat_a), mat_a);
  DLAF_ASSERT(matrix::single_tile_per_block(mat_a), mat_a);
  DLAF_ASSERT(matrix::square_block_size(mat_a), mat_a);
  DLAF_ASSERT(matrix::square_size(mat_b), mat_b);
  DLAF_ASSERT(matrix::single_tile_per_block(mat_b), mat_b);
  DLAF_ASSERT(matrix::square_block_size(mat_b), mat_b);
  DLAF_ASSERT(mat_a.size() == mat_b.size(), mat_a, mat_b);
  DLAF_ASSERT(mat_a.block_size() == mat_b.block_size(), mat_a, mat_b);
  DLAF_ASSERT(eigenvalues_index_begin == 0, eigenvalues_index_begin);
  DLAF_ASSERT(eigenvalues_index_end >= eigenvalues_index_begin, eigenvalues_index_end,
              eigenvalues_index_begin);
  DLAF_ASSERT(eigenvalues_index_end <= mat_a.size().rows(), eigenvalues_index_end, mat_a.size().rows());

  const SizeType size = mat_a.size().rows();

  matrix::Matrix<BaseType<T>, D> eigenvalues(LocalElementSize(size, 1),
                                             TileElementSize(mat_a.tile_size().rows(), 1));
  matrix::Matrix<T, D> eigenvectors(GlobalElementSize(size, size), mat_a.tile_size(), grid);

  hermitian_generalized_eigensolver<B, D, T>(grid, uplo, mat_a, mat_b, eigenvalues, eigenvectors,
                                             factorization, eigenvalues_index_begin,
                                             eigenvalues_index_end);

  return {std::move(eigenvalues), std::move(eigenvectors)};
}

}

/// @copydoc hermitian_generalized_eigensolver(blas::Uplo, Matrix<T, D>&, Matrix<T, D>&,
/// Matrix<BaseType<T>, D>&, Matrix<T, D>&)
///
/// @param eigenvalues_index_begin is the index of the first eigenvalue to compute
/// @pre @p eigenvalues_index_begin == 0
/// @param eigenvalues_index_end is the index of the last eigenvalue to compute (exclusive)
/// @pre @p eigenvalues_index_begin <= @p eigenvalues_index_end < N
template <Backend B, Device D, class T>
void hermitian_generalized_eigensolver(blas::Uplo uplo, Matrix<T, D>& mat_a, Matrix<T, D>& mat_b,
                                       Matrix<BaseType<T>, D>& eigenvalues, Matrix<T, D>& eigenvectors,
                                       const SizeType eigenvalues_index_begin,
                                       const SizeType eigenvalues_index_end) {
  using eigensolver::internal::Factorization;

  eigensolver::internal::hermitian_generalized_eigensolver<B, D, T>(
      uplo, mat_a, mat_b, eigenvalues, eigenvectors, Factorization::do_factorization,
      eigenvalues_index_begin, eigenvalues_index_end);
}

/// Generalized Eigensolver.
///
/// It solves the generalized eigenvalue problem A * x = lambda * B * x.
///
/// On exit:
/// - the lower triangle or the upper triangle (depending on @p uplo) of @p mat_a,
/// including the diagonal, is destroyed.
/// - @p mat_b contains the Cholesky decomposition of B
/// - @p eigenvalues contains all the eigenvalues lambda
/// - @p eigenvectors contains all the eigenvectors x
///
/// Implementation on local memory.
///
/// @param uplo specifies if upper or lower triangular part of @p mat_a and @p mat_b will be referenced
///
/// @param mat_a contains the Hermitian matrix A
/// @pre @p mat_a is not distributed
/// @pre @p mat_a has size (N x N)
/// @pre @p mat_a has block size (NB x NB)
/// @pre @p mat_a has tile size (NB x NB)
///
/// @param mat_b contains the Hermitian positive definite matrix B
/// @pre @p mat_b is not distributed
/// @pre @p mat_b has size (N x N)
/// @pre @p mat_b has block size (NB x NB)
/// @pre @p mat_b has tile size (NB x NB)
///
/// @param[out] eigenvalues contains the eigenvalues
/// @pre @p eigenvalues is not distributed
/// @pre @p eigenvalues has size (N x 1)
/// @pre @p eigenvalues has block size (NB x NB)
/// @pre @p eigenvalues has tile size (NB x NB)
///
/// @param[out] eigenvectors contains the eigenvectors
/// @pre @p eigenvectors is not distributed
/// @pre @p eigenvectors has size (N x N)
/// @pre @p eigenvectors has block size (NB x NB)
/// @pre @p eigenvectors has tile size (NB x NB)
template <Backend B, Device D, class T>
void hermitian_generalized_eigensolver(blas::Uplo uplo, Matrix<T, D>& mat_a, Matrix<T, D>& mat_b,
                                       Matrix<BaseType<T>, D>& eigenvalues, Matrix<T, D>& eigenvectors) {
  hermitian_generalized_eigensolver<B, D, T>(uplo, mat_a, mat_b, eigenvalues, eigenvectors, 0,
                                             mat_a.size().rows());
}

/// @copydoc hermitian_generalized_eigensolver(blas::Uplo, Matrix<T, D>&, Matrix<T, D>&) {
///
/// @param eigenvalues_index_begin is the index of the first eigenvalue to compute
/// @pre @p eigenvalues_index_begin >= 0
/// @param eigenvalues_index_end is the index of the last eigenvalue to compute (exclusive)
/// @pre @p eigenvalues_index_begin <= @p eigenvalues_index_end < N
template <Backend B, Device D, class T>
EigensolverResult<T, D> hermitian_generalized_eigensolver(blas::Uplo uplo, Matrix<T, D>& mat_a,
                                                          Matrix<T, D>& mat_b,
                                                          const SizeType eigenvalues_index_begin,
                                                          const SizeType eigenvalues_index_end) {
  using eigensolver::internal::Factorization;

  return eigensolver::internal::hermitian_generalized_eigensolver<B, D, T>(
      uplo, mat_a, mat_b, Factorization::do_factorization, eigenvalues_index_begin,
      eigenvalues_index_end);
}

/// Generalized Eigensolver.
///
/// It solves the generalized eigenvalue problem A * x = lambda * B * x.
///
/// On exit:
/// - the lower triangle or the upper triangle (depending on @p uplo) of @p mat_a,
/// including the diagonal, is destroyed.
/// - @p mat_b contains the Cholesky decomposition of B
///
/// Implementation on local memory.
///
/// @return struct ReturnEigensolverType with eigenvalues, as a vector<T>, and eigenvectors as a Matrix
/// @param uplo specifies if upper or lower triangular part of @p mat_a and @p mat_b will be referenced
///
/// @param mat_a contains the Hermitian matrix A
/// @pre @p mat_a is not distributed
/// @pre @p mat_a has size (N x N)
/// @pre @p mat_a has block size (NB x NB)
/// @pre @p mat_a has tile size (NB x NB)
///
/// @param mat_b contains the Hermitian positive definite matrix B
/// @pre @p mat_b is not distributed
/// @pre @p mat_b has size (N x N)
/// @pre @p mat_b has block size (NB x NB)
/// @pre @p mat_b has tile size (NB x NB)
///
/// @param eigenvalues_index_begin is the index of the first eigenvalue to compute
/// @pre @p eigenvalues_index_begin >= 0
/// @param eigenvalues_index_end is the index of the last eigenvalue to compute (exclusive)
/// @pre @p eigenvalues_index_end >= 0
/// @pre @p eigenvalues_index_end <= N
template <Backend B, Device D, class T>
EigensolverResult<T, D> hermitian_generalized_eigensolver(blas::Uplo uplo, Matrix<T, D>& mat_a,
                                                          Matrix<T, D>& mat_b) {
  return hermitian_generalized_eigensolver<B, D, T>(uplo, mat_a, mat_b, 0, mat_a.size().rows());
}

/// @copydoc hermitian_generalized_eigensolver_factorized(blas::Uplo, Matrix<T, D>&, Matrix<T, D>&,
/// Matrix<BaseType<T>, D>&, Matrix<T, D>&) Generalized Eigensolver.
///
/// @param eigenvalues_index_begin is the index of the first eigenvalue to compute
/// @pre @p eigenvalues_index_begin >= 0
/// @param eigenvalues_index_end is the index of the last eigenvalue to compute (exclusive)
/// @pre @p eigenvalues_index_begin <= @p eigenvalues_index_end < N
template <Backend B, Device D, class T>
void hermitian_generalized_eigensolver_factorized(
    blas::Uplo uplo, Matrix<T, D>& mat_a, Matrix<T, D>& mat_b, Matrix<BaseType<T>, D>& eigenvalues,
    Matrix<T, D>& eigenvectors, const SizeType eigenvalues_index_begin,
    const SizeType eigenvalues_index_end) {
  using eigensolver::internal::Factorization;

  eigensolver::internal::hermitian_generalized_eigensolver<B, D, T>(
      uplo, mat_a, mat_b, eigenvalues, eigenvectors, Factorization::already_factorized,
      eigenvalues_index_begin, eigenvalues_index_end);
}

/// Generalized Eigensolver.
///
/// It solves the generalized eigenvalue problem A * x = lambda * B * x.
///
/// On exit:
/// - the lower triangle or the upper triangle (depending on @p uplo) of @p mat_a,
/// including the diagonal, is destroyed.
/// - @p mat_b contains the Cholesky decomposition of B
/// - @p eigenvalues contains all the eigenvalues lambda
/// - @p eigenvectors contains all the eigenvectors x
///
/// Implementation on local memory.
///
/// @param uplo specifies if upper or lower triangular part of @p mat_a and @p mat_b will be referenced
///
/// @param mat_a contains the Hermitian matrix A
/// @pre @p mat_a is not distributed
/// @pre @p mat_a has size (N x N)
/// @pre @p mat_a has block size (NB x NB)
/// @pre @p mat_a has tile size (NB x NB)
///
/// @param mat_b contains the Cholesky factorisation of the Hermitian positive definite matrix B
/// @pre @p mat_b is not distributed
/// @pre @p mat_b has size (N x N)
/// @pre @p mat_b has block size (NB x NB)
/// @pre @p mat_b has tile size (NB x NB)
/// @pre @p mat_b is the result of a Cholesky factorization
///
/// @param[out] eigenvalues contains the eigenvalues
/// @pre @p eigenvalues is not distributed
/// @pre @p eigenvalues has size (N x 1)
/// @pre @p eigenvalues has block size (NB x NB)
/// @pre @p eigenvalues has tile size (NB x NB)
///
/// @param[out] eigenvectors contains the eigenvectors
/// @pre @p eigenvectors is not distributed
/// @pre @p eigenvectors has size (N x N)
/// @pre @p eigenvectors has block size (NB x NB)
/// @pre @p eigenvectors has tile size (NB x NB)
template <Backend B, Device D, class T>
void hermitian_generalized_eigensolver_factorized(blas::Uplo uplo, Matrix<T, D>& mat_a,
                                                  Matrix<T, D>& mat_b,
                                                  Matrix<BaseType<T>, D>& eigenvalues,
                                                  Matrix<T, D>& eigenvectors) {
  hermitian_generalized_eigensolver_factorized<B, D, T>(uplo, mat_a, mat_b, eigenvalues, eigenvectors, 0,
                                                        mat_a.size().rows());
}

/// @copydoc hermitian_generalized_eigensolver_factorized(blas::Uplo, Matrix<T, D>&, Matrix<T, D>&)
///
/// @param eigenvalues_index_begin is the index of the first eigenvalue to compute
/// @pre @p eigenvalues_index_begin >= 0
/// @param eigenvalues_index_end is the index of the last eigenvalue to compute (exclusive)
/// @pre @p eigenvalues_index_begin <= @p eigenvalues_index_end < N
template <Backend B, Device D, class T>
EigensolverResult<T, D> hermitian_generalized_eigensolver_factorized(
    blas::Uplo uplo, Matrix<T, D>& mat_a, Matrix<T, D>& mat_b, const SizeType eigenvalues_index_begin,
    const SizeType eigenvalues_index_end) {
  using eigensolver::internal::Factorization;

  return eigensolver::internal::hermitian_generalized_eigensolver<B, D, T>(
      uplo, mat_a, mat_b, Factorization::already_factorized, eigenvalues_index_begin,
      eigenvalues_index_end);
}

/// Generalized Eigensolver.
///
/// It solves the generalized eigenvalue problem A * x = lambda * B * x.
///
/// On exit:
/// - the lower triangle or the upper triangle (depending on @p uplo) of @p mat_a,
/// including the diagonal, is destroyed.
/// - @p mat_b contains the Cholesky decomposition of B
///
/// Implementation on local memory.
///
/// @return struct ReturnEigensolverType with eigenvalues, as a vector<T>, and eigenvectors as a Matrix
/// @param uplo specifies if upper or lower triangular part of @p mat_a and @p mat_b will be referenced
///
/// @param mat_a contains the Hermitian matrix A
/// @pre @p mat_a is not distributed
/// @pre @p mat_a has size (N x N)
/// @pre @p mat_a has block size (NB x NB)
/// @pre @p mat_a has tile size (NB x NB)
///
/// @param mat_b contains the Cholesky factorisation of the Hermitian positive definite matrix B
/// @pre @p mat_b is not distributed
/// @pre @p mat_b has size (N x N)
/// @pre @p mat_b has block size (NB x NB)
/// @pre @p mat_b has tile size (NB x NB)
/// @pre @p mat_b is the result of a Cholesky factorization
template <Backend B, Device D, class T>
EigensolverResult<T, D> hermitian_generalized_eigensolver_factorized(blas::Uplo uplo,
                                                                     Matrix<T, D>& mat_a,
                                                                     Matrix<T, D>& mat_b) {
  return hermitian_generalized_eigensolver_factorized<B, D, T>(uplo, mat_a, mat_b, 0,
                                                               mat_a.size().rows());
}

/// @copydoc hermitian_generalized_eigensolver(comm::CommunicatorGrid&, blas::Uplo, Matrix<T, D>&,
/// Matrix<T, D>&, Matrix<BaseType<T>, D>&, Matrix<T, D>&)
///
/// @param eigenvalues_index_begin is the index of the first eigenvalue to compute
/// @pre @p eigenvalues_index_begin == 0
/// @param eigenvalues_index_end is the index of the last eigenvalue to compute (exclusive)
/// @pre @p eigenvalues_index_begin <= @p eigenvalues_index_end < N
template <Backend B, Device D, class T>
void hermitian_generalized_eigensolver(comm::CommunicatorGrid& grid, blas::Uplo uplo,
                                       Matrix<T, D>& mat_a, Matrix<T, D>& mat_b,
                                       Matrix<BaseType<T>, D>& eigenvalues, Matrix<T, D>& eigenvectors,
                                       const SizeType eigenvalues_index_begin,
                                       const SizeType eigenvalues_index_end) {
  using eigensolver::internal::Factorization;

  eigensolver::internal::hermitian_generalized_eigensolver<B, D, T>(
      grid, uplo, mat_a, mat_b, eigenvalues, eigenvectors, Factorization::do_factorization,
      eigenvalues_index_begin, eigenvalues_index_end);
}

/// Generalized Eigensolver.
///
/// It solves the generalized eigenvalue problem A * x = lambda * B * x.
///
/// On exit:
/// - the lower triangle or the upper triangle (depending on @p uplo) of @p mat_a,
/// including the diagonal, is destroyed.
/// - @p mat_b contains the Cholesky decomposition of B
/// - @p eigenvalues contains all the eigenvalues lambda
/// - @p eigenvectors contains all the eigenvectors x
///
/// Implementation on distributed memory.
///
/// @param grid is the communicator grid on which the matrices @p mat_a and @p mat_b have been distributed,
/// @param uplo specifies if upper or lower triangular part of @p mat_a and @p mat_b will be referenced
///
/// @param mat_a contains the Hermitian matrix A
/// @pre @p mat_a is distributed according to @p grid
/// @pre @p mat_a has size (N x N)
/// @pre @p mat_a has block size (NB x NB)
/// @pre @p mat_a has tile size (NB x NB)
///
/// @param mat_b contains the Hermitian positive definite matrix B
/// @pre @p mat_b is distributed according to @p grid
/// @pre @p mat_b has size (N x N)
/// @pre @p mat_b has block size (NB x NB)
/// @pre @p mat_b has tile size (NB x NB)
///
/// @param eigenvalues is a N x 1 matrix which on output contains the eigenvalues
/// @pre @p eigenvalues is not distributed
/// @pre @p eigenvalues has size (N x 1)
/// @pre @p eigenvalues has block size (NB x 1)
/// @pre @p eigenvalues has tile size (NB x 1)
///
/// @param[out] eigenvectors contains the eigenvectors
/// @pre @p eigenvectors is distributed according to @p grid
/// @pre @p eigenvectors has size (N x N)
/// @pre @p eigenvectors has block size (NB x NB)
/// @pre @p eigenvectors has tile size (NB x NB)
template <Backend B, Device D, class T>
void hermitian_generalized_eigensolver(comm::CommunicatorGrid& grid, blas::Uplo uplo,
                                       Matrix<T, D>& mat_a, Matrix<T, D>& mat_b,
                                       Matrix<BaseType<T>, D>& eigenvalues, Matrix<T, D>& eigenvectors) {
  hermitian_generalized_eigensolver<B, D, T>(grid, uplo, mat_a, mat_b, eigenvalues, eigenvectors, 0,
                                             mat_a.size().rows());
}

/// @copydoc hermitian_generalized_eigensolver(comm::CommunicatorGrid&, blas::Uplo, Matrix<T, D>&,
/// Matrix<T, D>&)
///
/// @param eigenvalues_index_begin is the index of the first eigenvalue to compute
/// @pre @p eigenvalues_index_begin == 0
/// @param eigenvalues_index_end is the index of the last eigenvalue to compute (exclusive)
/// @pre @p eigenvalues_index_begin <= @p eigenvalues_index_end < N
template <Backend B, Device D, class T>
EigensolverResult<T, D> hermitian_generalized_eigensolver(comm::CommunicatorGrid& grid, blas::Uplo uplo,
                                                          Matrix<T, D>& mat_a, Matrix<T, D>& mat_b,
                                                          const SizeType eigenvalues_index_begin,
                                                          const SizeType eigenvalues_index_end) {
  using eigensolver::internal::Factorization;

  return eigensolver::internal::hermitian_generalized_eigensolver<B, D, T>(
      grid, uplo, mat_a, mat_b, Factorization::do_factorization, eigenvalues_index_begin,
      eigenvalues_index_end);
}

/// Generalized Eigensolver.
///
/// It solves the generalized eigenvalue problem A * x = lambda * B * x.
///
/// On exit:
/// - the lower triangle or the upper triangle (depending on @p uplo) of @p mat_a,
/// including the diagonal, is destroyed.
/// - @p mat_b contains the Cholesky decomposition of B
///
/// Implementation on distributed memory.
///
/// @return struct ReturnEigensolverType with eigenvalues, as a vector<T>, and eigenvectors as a Matrix
/// @param grid is the communicator grid on which the matrices @p mat_a and @p mat_b have been distributed,
/// @param uplo specifies if upper or lower triangular part of @p mat_a and @p mat_b will be referenced
///
/// @param mat_a contains the Hermitian matrix A
/// @pre @p mat_a is distributed according to @p grid
/// @pre @p mat_a has size (N x N)
/// @pre @p mat_a has block size (NB x NB)
/// @pre @p mat_a has tile size (NB x NB)
///
/// @param mat_b contains the Hermitian positive definite matrix B
/// @pre @p mat_b is distributed according to @p grid
/// @pre @p mat_b has size (N x N)
/// @pre @p mat_b has block size (NB x NB)
/// @pre @p mat_b has tile size (NB x NB)
template <Backend B, Device D, class T>
EigensolverResult<T, D> hermitian_generalized_eigensolver(comm::CommunicatorGrid& grid, blas::Uplo uplo,
                                                          Matrix<T, D>& mat_a, Matrix<T, D>& mat_b) {
  return hermitian_generalized_eigensolver<B, D, T>(grid, uplo, mat_a, mat_b, 0, mat_a.size().rows());
}

/// @copydoc hermitian_generalized_eigensolver_factorized(comm::CommunicatorGrid&, blas::Uplo, Matrix<T,
/// D>&, Matrix<T, D>&, Matrix<BaseType<T>, D>&, Matrix<T, D>&)
///
/// @param eigenvalues_index_begin is the index of the first eigenvalue to compute
/// @pre @p eigenvalues_index_begin == 0
/// @param eigenvalues_index_end is the index of the last eigenvalue to compute (exclusive)
/// @pre @p eigenvalues_index_begin <= @p eigenvalues_index_end < N
template <Backend B, Device D, class T>
void hermitian_generalized_eigensolver_factorized(
    comm::CommunicatorGrid& grid, blas::Uplo uplo, Matrix<T, D>& mat_a, Matrix<T, D>& mat_b,
    Matrix<BaseType<T>, D>& eigenvalues, Matrix<T, D>& eigenvectors,
    const SizeType eigenvalues_index_begin, const SizeType eigenvalues_index_end) {
  using eigensolver::internal::Factorization;
  eigensolver::internal::hermitian_generalized_eigensolver<B, D, T>(
      grid, uplo, mat_a, mat_b, eigenvalues, eigenvectors, Factorization::already_factorized,
      eigenvalues_index_begin, eigenvalues_index_end);
}

/// Generalized Eigensolver.
///
/// It solves the generalized eigenvalue problem A * x = lambda * B * x.
///
/// On exit:
/// - the lower triangle or the upper triangle (depending on @p uplo) of @p mat_a,
/// including the diagonal, is destroyed.
/// - @p mat_b contains the Cholesky decomposition of B
/// - @p eigenvalues contains all the eigenvalues lambda
/// - @p eigenvectors contains all the eigenvectors x
///
/// Implementation on distributed memory.
///
/// @param grid is the communicator grid on which the matrices @p mat_a and @p mat_b have been distributed,
/// @param uplo specifies if upper or lower triangular part of @p mat_a and @p mat_b will be referenced
///
/// @param mat_a contains the Hermitian matrix A
/// @pre @p mat_a is distributed according to @p grid
/// @pre @p mat_a has size (N x N)
/// @pre @p mat_a has block size (NB x NB)
/// @pre @p mat_a has tile size (NB x NB)
///
/// @param mat_b contains the Cholesky factorisation of the Hermitian positive definite matrix B
/// @pre @p mat_b is distributed according to @p grid
/// @pre @p mat_b has size (N x N)
/// @pre @p mat_b has block size (NB x NB)
/// @pre @p mat_b has tile size (NB x NB)
/// @pre @p mat_b is the result of a Cholesky factorization
///
/// @param eigenvalues is a N x 1 matrix which on output contains the eigenvalues
/// @pre @p eigenvalues is not distributed
/// @pre @p eigenvalues has size (N x 1)
/// @pre @p eigenvalues has block size (NB x 1)
/// @pre @p eigenvalues has tile size (NB x 1)
///
/// @param[out] eigenvectors contains the eigenvectors
/// @pre @p eigenvectors is distributed according to @p grid
/// @pre @p eigenvectors has size (N x N)
/// @pre @p eigenvectors has block size (NB x NB)
/// @pre @p eigenvectors has tile size (NB x NB)
template <Backend B, Device D, class T>
void hermitian_generalized_eigensolver_factorized(comm::CommunicatorGrid& grid, blas::Uplo uplo,
                                                  Matrix<T, D>& mat_a, Matrix<T, D>& mat_b,
                                                  Matrix<BaseType<T>, D>& eigenvalues,
                                                  Matrix<T, D>& eigenvectors) {
  hermitian_generalized_eigensolver_factorized<B, D, T>(grid, uplo, mat_a, mat_b, eigenvalues,
                                                        eigenvectors, 0, mat_a.size().rows());
}

/// @copydoc hermitian_generalized_eigensolver_factorized(comm::CommunicatorGrid&, blas::Uplo, Matrix<T,
/// D>&, Matrix<T, D>&)
///
/// @param eigenvalues_index_begin is the index of the first eigenvalue to compute
/// @pre @p eigenvalues_index_begin == 0
/// @param eigenvalues_index_end is the index of the last eigenvalue to compute (exclusive)
/// @pre @p eigenvalues_index_end <= N
template <Backend B, Device D, class T>
EigensolverResult<T, D> hermitian_generalized_eigensolver_factorized(
    comm::CommunicatorGrid& grid, blas::Uplo uplo, Matrix<T, D>& mat_a, Matrix<T, D>& mat_b,
    const SizeType eigenvalues_index_begin, const SizeType eigenvalues_index_end) {
  using eigensolver::internal::Factorization;

  return eigensolver::internal::hermitian_generalized_eigensolver<B, D, T>(
      grid, uplo, mat_a, mat_b, Factorization::already_factorized, eigenvalues_index_begin,
      eigenvalues_index_end);
}

/// Generalized Eigensolver.
///
/// It solves the generalized eigenvalue problem A * x = lambda * B * x.
///
/// On exit:
/// - the lower triangle or the upper triangle (depending on @p uplo) of @p mat_a,
/// including the diagonal, is destroyed.
/// - @p mat_b contains the Cholesky decomposition of B
///
/// Implementation on distributed memory.
///
/// @return struct ReturnEigensolverType with eigenvalues, as a vector<T>, and eigenvectors as a Matrix
/// @param grid is the communicator grid on which the matrices @p mat_a and @p mat_b have been distributed,
/// @param uplo specifies if upper or lower triangular part of @p mat_a and @p mat_b will be referenced
///
/// @param mat_a contains the Hermitian matrix A
/// @pre @p mat_a is distributed according to @p grid
/// @pre @p mat_a has size (N x N)
/// @pre @p mat_a has block size (NB x NB)
/// @pre @p mat_a has tile size (NB x NB)
///
/// @param mat_b contains the Cholesky factorisation of the Hermitian positive definite matrix B
/// @pre @p mat_b is distributed according to @p grid
/// @pre @p mat_b has size (N x N)
/// @pre @p mat_b has block size (NB x NB)
/// @pre @p mat_b has tile size (NB x NB)
/// @pre @p mat_b is the result of a Cholesky factorization
template <Backend B, Device D, class T>
EigensolverResult<T, D> hermitian_generalized_eigensolver_factorized(
    comm::CommunicatorGrid& grid, blas::Uplo uplo, Matrix<T, D>& mat_a, Matrix<T, D>& mat_b) {
  return hermitian_generalized_eigensolver_factorized<B, D, T>(grid, uplo, mat_a, mat_b, 0,
                                                               mat_a.size().rows());
}
}
