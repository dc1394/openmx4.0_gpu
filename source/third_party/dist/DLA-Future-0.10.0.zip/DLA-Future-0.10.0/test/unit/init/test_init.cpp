//
// Distributed Linear Algebra with Future (DLAF)
//
// Copyright (c) ETH Zurich
// All rights reserved.
//
// Please, refer to the LICENSE file in the root directory.
// SPDX-License-Identifier: BSD-3-Clause
//

#include <cstddef>
#include <cstdlib>
#include <memory>
#include <string>
#include <utility>

#include <pika/init.hpp>

#include <dlaf/init.h>

#include <gtest/gtest.h>

static const char* binary_name = "init_test";
static const char* env_var_name = "DLAF_NUM_GPU_BLAS_HANDLES";
static const char* command_line_option_name = "--dlaf:num-gpu-blas-handles";
static const char* print_bind = "--pika:print-bind";

static int argc_without_option = 1;
static const char* argv_without_option[] = {binary_name};

static int pika_argc_without_option = 2;
static const char* pika_argv_without_option[] = {binary_name, print_bind};

enum class InitializerType {
  RAII,
  InitializeFinalize,
};

// This helper primarily exists to test that the free function dlaf::finalize
// and the RAII helper dlaf::ScopedInitializer constructor accept the same
// arguments and behave the same.
struct InitializeTester {
  InitializerType type_;
  std::unique_ptr<dlaf::ScopedInitializer> init_ = nullptr;

  template <typename... Args>
  InitializeTester(InitializerType type, Args&&... args) : type_(type) {
    if (type_ == InitializerType::RAII) {
      init_ = std::make_unique<dlaf::ScopedInitializer>(std::forward<Args>(args)...);
    }
    else if (type_ == InitializerType::InitializeFinalize) {
      dlaf::initialize(std::forward<Args>(args)...);
    }
    else {
      EXPECT_TRUE(false);
    }
  }

  ~InitializeTester() {
    if (type_ == InitializerType::RAII) {
    }
    else if (type_ == InitializerType::InitializeFinalize) {
      dlaf::finalize();
    }
    else {
      EXPECT_TRUE(false);
    }
  }

  InitializeTester(InitializeTester&&) = delete;
  InitializeTester(const InitializeTester&) = delete;
  InitializeTester& operator=(InitializeTester&&) = delete;
  InitializeTester& operator=(const InitializeTester&) = delete;
};

static InitializerType current_initializer_type;

template <typename F>
void initialize_tester_helper(F&& f) {
  current_initializer_type = InitializerType::RAII;
  f();

  current_initializer_type = InitializerType::InitializeFinalize;
  f();
}

const auto initializer_types =
    ::testing::Values(InitializerType::RAII, InitializerType::InitializeFinalize);

class InitTest : public ::testing::TestWithParam<InitializerType> {};

int precedence_main(int, char*[]) {
  const dlaf::configuration default_cfg;
  const std::size_t default_val = default_cfg.num_gpu_blas_handles;
  // Note that this test doesn't mean that the default value has to be 16. It is
  // included to help catch unexpected changes in the configuration handling.
  EXPECT_EQ(default_val, 16);

  // Make sure environment is clean for the test.
  unsetenv(env_var_name);

  // Default configuration.
  {
    InitializeTester init(current_initializer_type, argc_without_option, argv_without_option);
    dlaf::configuration cfg = dlaf::internal::getConfiguration();
    EXPECT_EQ(default_val, cfg.num_gpu_blas_handles);
  }

  // User configuration should take precedence over default configuration.
  {
    dlaf::configuration user_cfg = default_cfg;
    user_cfg.num_gpu_blas_handles = default_val + 1;

    InitializeTester init(current_initializer_type, argc_without_option, argv_without_option, user_cfg);
    dlaf::configuration cfg = dlaf::internal::getConfiguration();
    EXPECT_EQ(user_cfg.num_gpu_blas_handles, cfg.num_gpu_blas_handles);
  }

  // Environment variables should take precedence over user configuration.
  {
    dlaf::configuration user_cfg = default_cfg;
    user_cfg.num_gpu_blas_handles = default_val + 1;
    const std::size_t env_var_val = user_cfg.num_gpu_blas_handles + 1;
    const std::string env_var_val_str = std::to_string(env_var_val);
    setenv(env_var_name, env_var_val_str.c_str(), 1);

    InitializeTester init(current_initializer_type, argc_without_option, argv_without_option, user_cfg);
    dlaf::configuration cfg = dlaf::internal::getConfiguration();
    EXPECT_EQ(env_var_val, cfg.num_gpu_blas_handles);
  }

  // Command-line options should take precedence over environment variables.
  {
    dlaf::configuration user_cfg = default_cfg;
    user_cfg.num_gpu_blas_handles = default_val + 1;
    const std::size_t env_var_val = user_cfg.num_gpu_blas_handles + 1;
    const std::string env_var_val_str = std::to_string(env_var_val);
    setenv(env_var_name, env_var_val_str.c_str(), 1);
    const std::size_t command_line_option_val = env_var_val + 1;
    const std::string command_line_option_val_str = std::to_string(command_line_option_val);
    const std::string command_line_option_str =
        command_line_option_name + std::string("=") + command_line_option_val_str;
    const int argc_with_option = 2;
    const char* argv_with_option[] = {binary_name, command_line_option_str.c_str()};

    InitializeTester init(current_initializer_type, argc_with_option, argv_with_option, user_cfg);
    dlaf::configuration cfg = dlaf::internal::getConfiguration();
    EXPECT_EQ(command_line_option_val, cfg.num_gpu_blas_handles);
  }

  pika::finalize();
  return EXIT_SUCCESS;
}

TEST_P(InitTest, Precedence) {
  current_initializer_type = GetParam();

  pika::init(precedence_main, pika_argc_without_option, pika_argv_without_option);
}

int vm_no_command_line_option_main(pika::program_options::variables_map& vm) {
  const dlaf::configuration default_cfg;
  const std::size_t default_val = default_cfg.num_gpu_blas_handles;
  // Note that this test doesn't mean that the default value has to be 16. It is
  // included to help catch unexpected changes in the configuration handling.
  EXPECT_EQ(default_val, 16);

  // Make sure environment is clean for the test.
  unsetenv(env_var_name);

  // Default configuration.
  {
    InitializeTester init(current_initializer_type, vm);
    dlaf::configuration cfg = dlaf::internal::getConfiguration();
    EXPECT_EQ(default_val, cfg.num_gpu_blas_handles);
  }

  // User configuration should take precedence over default configuration.
  {
    dlaf::configuration user_cfg = default_cfg;
    user_cfg.num_gpu_blas_handles = default_val + 1;

    InitializeTester init(current_initializer_type, vm, user_cfg);
    dlaf::configuration cfg = dlaf::internal::getConfiguration();
    EXPECT_EQ(user_cfg.num_gpu_blas_handles, cfg.num_gpu_blas_handles);
  }

  // Environment variables should take precedence over user configuration.
  {
    dlaf::configuration user_cfg = default_cfg;
    user_cfg.num_gpu_blas_handles = default_val + 1;
    const std::size_t env_var_val = user_cfg.num_gpu_blas_handles + 1;
    const std::string env_var_val_str = std::to_string(env_var_val);
    setenv(env_var_name, env_var_val_str.c_str(), 1);

    InitializeTester init(current_initializer_type, vm, user_cfg);
    dlaf::configuration cfg = dlaf::internal::getConfiguration();
    EXPECT_EQ(env_var_val, cfg.num_gpu_blas_handles);
  }

  // Command-line options should take precedence over environment variables.
  {
    dlaf::configuration user_cfg = default_cfg;
    user_cfg.num_gpu_blas_handles = default_val + 1;
    const std::size_t env_var_val = user_cfg.num_gpu_blas_handles + 1;
    const std::string env_var_val_str = std::to_string(env_var_val);
    setenv(env_var_name, env_var_val_str.c_str(), 1);
    const std::size_t command_line_option_val = env_var_val + 1;
    const std::string command_line_option_val_str = std::to_string(command_line_option_val);
    const std::string command_line_option_str =
        command_line_option_name + std::string("=") + command_line_option_val_str;
    const int argc_with_option = 2;
    const char* argv_with_option[] = {binary_name, command_line_option_str.c_str()};

    InitializeTester init(current_initializer_type, argc_with_option, argv_with_option, user_cfg);
    dlaf::configuration cfg = dlaf::internal::getConfiguration();
    EXPECT_EQ(command_line_option_val, cfg.num_gpu_blas_handles);
  }

  pika::finalize();
  return EXIT_SUCCESS;
}

TEST_P(InitTest, VariablesMapNoCommandLineOption) {
  current_initializer_type = GetParam();

  pika::init(vm_no_command_line_option_main, pika_argc_without_option, pika_argv_without_option);
}

int vm_command_line_option_main(pika::program_options::variables_map& vm) {
  dlaf::configuration default_cfg;
  const std::size_t default_val = default_cfg.num_gpu_blas_handles;

  // Command-line options should take precedence over everything else.
  {
    dlaf::configuration user_cfg = default_cfg;
    user_cfg.num_gpu_blas_handles = default_val + 1;
    const std::size_t env_var_val = user_cfg.num_gpu_blas_handles + 1;
    const std::string env_var_val_str = std::to_string(env_var_val);
    setenv(env_var_name, env_var_val_str.c_str(), 1);
    const std::size_t command_line_option_val = env_var_val + 1;

    InitializeTester init(current_initializer_type, vm, user_cfg);
    dlaf::configuration cfg = dlaf::internal::getConfiguration();
    EXPECT_EQ(command_line_option_val, cfg.num_gpu_blas_handles);
  }

  pika::finalize();
  return EXIT_SUCCESS;
}

TEST_P(InitTest, VariablesMapCommandLineOption) {
  current_initializer_type = GetParam();

  pika::program_options::options_description options("options");
  options.add(dlaf::getOptionsDescription());

  pika::init_params p;
  p.desc_cmdline = options;

  dlaf::configuration default_cfg;
  const std::size_t default_val = default_cfg.num_gpu_blas_handles;
  // Note that this test doesn't mean that the default value has to be 16. It is
  // included to help catch unexpected changes in the configuration handling.
  EXPECT_EQ(default_val, 16);

  std::size_t command_line_option_val = default_val + 3;
  std::string command_line_option_val_str = std::to_string(command_line_option_val);
  std::string command_line_option_str =
      command_line_option_name + std::string("=") + command_line_option_val_str;
  int argc_with_option = 3;
  const char* argv_with_option[] = {binary_name, command_line_option_str.c_str(), print_bind};

  pika::init(vm_command_line_option_main, argc_with_option, argv_with_option, p);
}

INSTANTIATE_TEST_SUITE_P(Init, InitTest, initializer_types);
