!
!    The ELPA library was originally created by the ELPA consortium,
!    consisting of the following organizations:
!
!    - Max Planck Computing and Data Facility (MPCDF), formerly known as
!      Rechenzentrum Garching der Max-Planck-Gesellschaft (RZG),
!    - Bergische Universität Wuppertal, Lehrstuhl für angewandte
!      Informatik,
!    - Technische Universität München, Lehrstuhl für Informatik mit
!      Schwerpunkt Wissenschaftliches Rechnen ,
!    - Fritz-Haber-Institut, Berlin, Abt. Theorie,
!    - Max-Plack-Institut für Mathematik in den Naturwissenschaften,
!      Leipzig, Abt. Komplexe Strukutren in Biologie und Kognition,
!      and
!    - IBM Deutschland GmbH
!
!    This particular source code file contains additions, changes and
!    enhancements authored by Intel Corporation which is not part of
!    the ELPA consortium.
!
!    More information can be found here:
!    http://elpa.mpcdf.mpg.de/
!
!    ELPA is free software: you can redistribute it and/or modify
!    it under the terms of the version 3 of the license of the
!    GNU Lesser General Public License as published by the Free
!    Software Foundation.
!
!    ELPA is distributed in the hope that it will be useful,
!    but WITHOUT ANY WARRANTY; without even the implied warranty of
!    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
!    GNU Lesser General Public License for more details.
!
!    You should have received a copy of the GNU Lesser General Public License
!    along with ELPA.  If not, see <http://www.gnu.org/licenses/>
!
!    ELPA reflects a substantial effort on the part of the original
!    ELPA consortium, and we ask you to respect the spirit of the
!    license that we chose: i.e., please contribute any changes you
!    may have back to the original ELPA library distribution, and keep
!    any derivatives of ELPA under the same license that we chose for
!    the original distribution, the GNU Lesser General Public License.
!
!
! ELPA1 -- Faster replacements for ScaLAPACK symmetric eigenvalue routines
!
! Copyright of the original code rests with the authors inside the ELPA
! consortium. The copyright of any additional modifications shall rest
! with their original authors, but shall adhere to the licensing terms
! distributed along with the original code in the file "COPYING".
!
! Author: A. Marek, MPCDF

#include "../general/sanity.F90"
#include "../general/error_checking.inc"

#undef USE_CCL_HERMITIAN_MULTIPLY
#if defined(WITH_NVIDIA_NCCL) || defined(WITH_AMD_RCCL)
#define USE_CCL_HERMITIAN_MULTIPLY
#endif

  use elpa1_compute
  use elpa_mpi
  use precision
  use elpa_abstract_impl
  use, intrinsic :: iso_c_binding
  use elpa_gpu
  use mod_check_for_gpu
  use elpa_blas_interfaces
  use ELPA_utilities, only : local_index, greatest_common_divisor, check_deallocate_f, check_dealloc_gpu_f, &
                             check_host_dealloc_gpu_f, check_alloc_gpu_f, check_host_alloc_gpu_f, &
                             check_host_unregister_gpu_f, check_memcpy_gpu_f, check_allocate_f, &
                             check_host_register_gpu_f, check_alloc, error_unit
  use mod_query_gpu_usage
#ifdef WITH_GPU_STREAMS
  use elpa_gpu_util
#endif
#if defined(WITH_NVIDIA_GPU_VERSION) && defined(WITH_NVTX)
  use cuda_functions ! for NVTX labels
#elif defined(WITH_AMD_GPU_VERSION) && defined(WITH_ROCTX)
  use hip_functions  ! for ROCTX labels
#endif
#if defined(USE_CCL_HERMITIAN_MULTIPLY)
  use elpa_ccl_gpu
#endif
  use multiply_a_b_gpu
  implicit none

#include "../../src/general/precision_kinds.F90"
  class(elpa_abstract_impl_t), intent(inout)   :: obj

  character*1                                  :: uplo_a, uplo_c, trans_a, trans_b

  integer(kind=ik), intent(in)                 :: ldb, ldbCols, ldc, ldcCols
  integer(kind=ik)                             :: na, ncb
#ifndef DEVICE_POINTER
#ifdef USE_ASSUMED_SIZE
  MATH_DATATYPE(kind=rck)                      :: a(obj%local_nrows,*), b(ldb,*), c(ldc,*)
#else
  MATH_DATATYPE(kind=rck)                      :: a(obj%local_nrows,obj%local_ncols), b(ldb,ldbCols), c(ldc,ldcCols)
#endif
#else /* DEVICE_POINTER */
  ! dummy variables
  MATH_DATATYPE(kind=rck), allocatable         :: a(:,:), b(:,:), c(:,:)
  type(c_ptr)                                  :: aDev, bDev, cDev
#endif /* DEVICE_POINTER */

  integer(kind=ik)                             :: my_prow, my_pcol, np_rows, np_cols, myid
  integer(kind=MPI_KIND)                       :: my_prowMPI, my_pcolMPI, np_rowsMPI, np_colsMPI
  integer(kind=MPI_KIND)                       :: mpierr, myidMPI
  integer(kind=ik)                             :: l_cols, l_rows, l_rows_np
  integer(kind=ik)                             :: n
  integer(kind=ik)                             :: np, nb, nblk_mult, lrs, lre, lcs, lce
  integer(kind=ik)                             :: gcol_min, gcol, goff
  integer(kind=ik)                             :: nstor, nstor0, nr_done, noff, np_bc, n_aux_bc, nvals
  integer(kind=ik), allocatable                :: lrs_save(:), lre_save(:), n_aux_bc_save(:)

  logical                                      :: a_lower, a_upper, c_lower, c_upper
  MATH_DATATYPE(kind=rck)                      :: beta
  MATH_DATATYPE(kind=rck), pointer, contiguous :: aux_mat(:,:), tmp1(:)
  MATH_DATATYPE(kind=rck), pointer, contiguous :: tmp2d(:,:)
  MATH_DATATYPE(kind=rck), allocatable         :: aux_bc(:)
  logical                                      :: wantDebug
  integer(kind=ik)                             :: istat, debug
  character(200)                               :: errorMessage
  character(20)                                :: gpuString
  logical                                      :: success, successGPU, successGPU2
  logical                                      :: useGPU
  integer(kind=c_int)                          :: numGPU, blocking, SM_count
  integer(kind=ik)                             :: mpi_comm_rows, mpi_comm_cols, mpi_comm_all
  integer(kind=ik)                             :: nblk, matrixRows, matrixCols, error
  integer(kind=ik)                             :: multiply_at_a
  integer(kind=c_intptr_t)                     :: aux_bc_dev, aux_mat_dev, tmp1_dev
  integer(kind=c_intptr_t)                     :: lrs_save_dev, lre_save_dev, n_aux_bc_save_dev

  integer(kind=c_intptr_t)                     :: a_dev
  integer(kind=c_intptr_t)                     :: b_dev
  integer(kind=c_intptr_t)                     :: c_dev

  type(c_ptr)                                  :: aux_host
  integer(kind=c_intptr_t)                     :: num
  integer(kind=c_intptr_t)                     :: aux_off, a_off, b_off
  integer(kind=c_intptr_t), parameter          :: size_of_datatype = size_of_&
                                                            &PRECISION&
                                                            &_&
                                                            &MATH_DATATYPE

  integer(kind=c_intptr_t)                     :: gpuHandle, my_stream
  integer(kind=c_int)                          :: gpu_hermitian_multiply

  logical                                      :: useCCL
#if defined(USE_CCL_HERMITIAN_MULTIPLY)
  integer(kind=c_intptr_t)                     :: ccl_comm_rows, ccl_comm_cols
  integer(kind=c_int)                          :: cclDataType
  integer(kind=ik)                             :: k_datatype
#endif

  integer(kind=c_intptr_t)                     :: aux_dev
  integer(kind=c_int)                          :: gpu


#ifdef WITH_NVTX
  call nvtxRangePush("hermitian_multiply")
#endif

  success = .true.
  useGPU = .false.
  useCCL = .false.
#if defined(USE_CCL_HERMITIAN_MULTIPLY)
    useCCL = obj%gpu_setup%useCCL
#endif

  call obj%get("debug", debug, error)
  if (error .ne. ELPA_OK) then
    write(error_unit,*) "elpa_hermitian_multiply: Problem getting option for debug settings. Aborting..."
    success = .false.
    return
  endif
  if (debug == 1) then
    wantDebug = .true.
  else
    wantDebug = .false.
  endif


#if !defined(DEVICE_POINTER)

#if defined(WITH_NVIDIA_GPU_VERSION) || defined(WITH_AMD_GPU_VERSION) || defined(WITH_OPENMP_OFFLOAD_GPU_VERSION) || defined(WITH_SYCL_GPU_VERSION)
  if (.not.(query_gpu_usage(obj, "ELPA_MULITPLY_AB", useGPU))) then
    print *,"ELPA_MULITPLY_AB: Problem querrying settings for GPU Aborting..."
    stop 1
  endif
#endif

  ! check whether the above setting should be overriden
  if (obj%is_set("gpu_hermitian_multiply") == 1) then
    call obj%get("gpu_hermitian_multiply", gpu_hermitian_multiply, error)
    if (error .ne. ELPA_OK) then
      print *,"Problem getting option for gpu_hermitian_mutltiply. Aborting..."
      stop 1
    endif
    if (useGPU .and. gpu_hermitian_multiply .eq. 0) then
      useGPU = .false.
    else if (.not.(useGPU) .and. gpu_hermitian_multiply .eq. 1) then
      useGPU = .true.
    else
    endif
  else
    ! no override by user
    ! keep seeting as found before
  endif

#else /* DEVICE_POINTER */

  useGPU = .true.

  a_dev = transfer(aDev, a_dev)
  b_dev = transfer(bDev, b_dev)
  c_dev = transfer(cDev, c_dev)

#endif /* DEVICE_POINTER */

  if(useGPU) then
    gpuString = "_gpu"
  else
    gpuString = ""
  endif

  call obj%timer%start("elpa_hermitian_multiply_&
  &MATH_DATATYPE&
  &_&
  &PRECISION&
  &"//gpuString)

  na          = obj%na
  nblk        = obj%nblk
  matrixRows  = obj%local_nrows
  matrixCols  = obj%local_ncols

  mpi_comm_all    = obj%mpi_setup%mpi_comm_parent
  mpi_comm_cols   = obj%mpi_setup%mpi_comm_cols
  mpi_comm_rows   = obj%mpi_setup%mpi_comm_rows

  myid    = obj%mpi_setup%myRank_comm_parent
  my_prow = obj%mpi_setup%myRank_comm_rows
  my_pcol = obj%mpi_setup%myRank_comm_cols

  np_rows = obj%mpi_setup%nRanks_comm_rows
  np_cols = obj%mpi_setup%nRanks_comm_cols

  call obj%get("multiply_at_a", multiply_at_a, error)
  if (error .ne. ELPA_OK) then
    write(error_unit,*) "Problem getting option for multiply_at_a. Aborting..."
    stop 1
  endif

  if (multiply_at_a == 0) then ! C = A^T * B
    l_rows = local_index(na,  my_prow, np_rows, nblk, -1) ! Local rows of a and b
    l_cols = local_index(ncb, my_pcol, np_cols, nblk, -1) ! Local cols of b
  else ! C = A^T * A
    l_rows = local_index(ncb, my_prow, np_rows, nblk, -1) ! Local rows of b (=a)
    l_cols = local_index(na,  my_pcol, np_cols, nblk, -1) ! Local cols of b (=a)
  endif
  
  ! Block factor for matrix multiplications, must be a multiple of nblk

  if (obj%is_set("blocking_in_multiply") == 1) then
    call obj%get("blocking_in_multiply", blocking, error)
    if (error .ne. ELPA_OK) then
      write(error_unit,*) "elpa_hermitian_multiply: Problem in getting keyword 'blocking_in_multiply'. Aborting..."
      stop 1
    endif
    nblk_mult = (blocking/nblk+1) * nblk
  else ! is_set
    ! different 'blocking' can be favorable for different problems (e.g. NCCL vs non-NCCL, FF vs FU vs UU)
    ! performance difference can be up to 10%
    ! (auto-) tuning might be recommended to the user
    if (useGPU .and. useCCL) then
      if (na/np_rows <= 256) then
       nblk_mult = (63/nblk+1)*nblk
       blocking = 63
      else
        nblk_mult = (351/nblk+1)*nblk
        blocking = 351
      endif
    else ! useGPU
      if (na/np_rows <= 256) then
        nblk_mult = (31/nblk+1)*nblk
      else
        nblk_mult = (63/nblk+1)*nblk
      endif
    endif ! useGPU
  endif ! is_set
  
  if (wantDebug .and. myid==0) print *, "blocking_in_multiply=", blocking, "nblk_mult=", nblk_mult

  if (useGPU) then
    call obj%timer%start("check_for_gpu")
    if (check_for_gpu(obj, myid, numGPU, wantDebug)) then
      ! set the neccessary parameters
      call set_gpu_parameters()
    else
      write(error_unit,*) "GPUs are requested but not detected! Aborting..."
      success = .false.
      return
    endif
    call obj%timer%stop("check_for_gpu")
    
    SM_count = obj%gpu_setup%gpuSMcount

#ifdef WITH_GPU_STREAMS    
    my_stream = obj%gpu_setup%my_stream
#endif

#if defined(USE_CCL_HERMITIAN_MULTIPLY)
    ccl_comm_rows = obj%gpu_setup%ccl_comm_rows
    ccl_comm_cols = obj%gpu_setup%ccl_comm_cols

#if   REALCASE == 1 && defined(DOUBLE_PRECISION)
    cclDataType = cclDouble
    k_datatype = 1
#elif REALCASE == 1 && defined(SINGLE_PRECISION)
    cclDataType = cclFloat
    k_datatype = 1
#elif COMPLEXCASE == 1 && defined(DOUBLE_PRECISION)
    cclDataType = cclDouble
    k_datatype = 2
#elif COMPLEXCASE == 1 && defined(SINGLE_PRECISION)
    cclDataType = cclFloat
    k_datatype = 2
#endif
#endif /* defined(USE_CCL_HERMITIAN_MULTIPLY) */

#if !defined(DEVICE_POINTER)
    if (wantDebug) call obj%timer%start("gpu_malloc")
    num = ldc*ldcCols*size_of_datatype
    successGPU = gpu_malloc(c_dev, num)
    check_alloc_gpu("elpa_hermitian_multiply: c_dev", successGPU)
    ! no copy from c to c_dev needed since c will be overwritten anyway
    if (wantDebug) call obj%timer%stop("gpu_malloc")
#endif

#if !defined(DEVICE_POINTER)
    if (multiply_at_a == 0) then ! C = A^T * B
      ! copy b to b_dev
      if (wantDebug) call obj%timer%start("gpu_malloc")
      num = ldb*ldbCols*size_of_datatype
      successGPU = gpu_malloc(b_dev, num)
      check_alloc_gpu("elpa_hermitian_multiply: b_dev", successGPU)
      if (wantDebug) call obj%timer%stop("gpu_malloc")

      call obj%timer%start("gpu_memcpy")
#ifdef WITH_GPU_STREAMS
      call gpu_memcpy_async_and_stream_synchronize &
      ("elpa_hermitian_multiply: b to b_dev", b_dev, 0_c_intptr_t, &
                                         b(1:ldb,1:ldbCols), &
                                         1, 1, num, gpuMemcpyHostToDevice, my_stream, .false., .true., .false.)
#else
      successGPU = gpu_memcpy(b_dev,int(loc(b),kind=c_intptr_t), num, gpuMemcpyHostToDevice)
      check_memcpy_gpu("elpa_hermitian_multiply: b to b_dev", successGPU)
#endif
      call obj%timer%stop("gpu_memcpy")
    endif ! (multiply_at_a == 0)
#else /* DEVICE_POINTER */

#endif /* DEVICE_POINTER */

    num = l_rows*nblk_mult*size_of_datatype
#if !defined(WITH_OPENMP_OFFLOAD_GPU_VERSION) && !defined(WITH_SYCL_GPU_VERSION)
    if (wantDebug) call obj%timer%start("gpu_malloc_host")
    successGPU = gpu_malloc_host(aux_host, num) ! aux_host is needed, because pinning host memory can be done only for 1D arrays
    check_host_alloc_gpu("elpa_hermitian_multiply: aux_host", successGPU)
    call c_f_pointer(aux_host, aux_mat, (/l_rows,nblk_mult/))
    if (wantDebug) call obj%timer%stop("gpu_malloc_host")
#else
    allocate(aux_mat(l_rows, nblk_mult), stat=istat, errmsg=errorMessage)
    check_allocate("elpa_hermitian_multiply: aux_mat", istat, errorMessage)
#endif
    if (wantDebug) call obj%timer%start("gpu_malloc")
    successGPU = gpu_malloc(aux_mat_dev, num)
    check_alloc_gpu("elpa_hermitian_multiply: aux_mat_dev", successGPU)

    num = nblk_mult*l_cols*size_of_datatype
    successGPU = gpu_malloc(tmp1_dev, num)
    check_alloc_gpu("elpa_hermitian_multiply: tmp1_dev", successGPU)
    if (wantDebug) call obj%timer%stop("gpu_malloc")
  else ! useGPU
    allocate(aux_mat(l_rows,nblk_mult), stat=istat, errmsg=errorMessage)
    check_allocate("elpa_hermitian_multiply: aux_mat", istat, errorMessage)
  endif ! useGPU

  if (.not. useCCL) then
    allocate(tmp1(nblk_mult*l_cols), stat=istat, errmsg=errorMessage)
    check_allocate("elpa_hermitian_multiply: tmp1", istat, errorMessage)

    if (useGPU) then
#if !defined(WITH_OPENMP_OFFLOAD_GPU_VERSION) && !defined(WITH_SYCL_GPU_VERSION)     
    successGPU = gpu_host_register(int(loc(tmp1),kind=c_intptr_t), nblk_mult*l_cols*size_of_datatype, gpuHostRegisterDefault)
    check_host_register_gpu("elpa_hermitian_multiply: tmp1", successGPU)
#endif
    endif
  endif ! (.not. useCCL) 
  
  allocate(lrs_save(nblk), stat=istat, errmsg=errorMessage)
  check_allocate("elpa_hermitian_multiply: lrs_save", istat, errorMessage)

  allocate(lre_save(nblk), stat=istat, errmsg=errorMessage)
  check_allocate("elpa_hermitian_multiply: lre_save", istat, errorMessage)
  
  allocate(n_aux_bc_save(nblk), stat=istat, errmsg=errorMessage)
  check_allocate("elpa_hermitian_multiply: n_aux_bc_save", istat, errorMessage)
  
  if (useGPU) then
    num = nblk*size_of_int
    successGPU = gpu_malloc(lrs_save_dev, num)
    check_alloc_gpu("elpa_hermitian_multiply: lrs_save_dev", successGPU)

    successGPU = gpu_malloc(lre_save_dev, num)
    check_alloc_gpu("elpa_hermitian_multiply: lre_save_dev", successGPU)

    successGPU = gpu_malloc(n_aux_bc_save_dev, num)
    check_alloc_gpu("elpa_hermitian_multiply: n_aux_bc_save_dev", successGPU)
  endif

  allocate(aux_bc(l_rows*nblk), stat=istat, errmsg=errorMessage)
  check_allocate("elpa_hermitian_multiply: aux_bc", istat, errorMessage)
  
  if (useGPU .and. .not. useCCL) then
    if (wantDebug) call obj%timer%start("gpu_host_register")
#if !defined(WITH_OPENMP_OFFLOAD_GPU_VERSION) && !defined(WITH_SYCL_GPU_VERSION)
    successGPU = gpu_host_register(int(loc(aux_bc),kind=c_intptr_t), l_rows*nblk*size_of_datatype, gpuHostRegisterDefault)
    check_host_register_gpu("elpa_hermitian_multiply: aux_bc", successGPU)
#endif
    if (wantDebug) call obj%timer%stop("gpu_host_register")
  endif

  a_lower = .false.
  a_upper = .false.
  c_lower = .false.
  c_upper = .false.


  if (multiply_at_a == 0) then ! C = A^T * B
    if (uplo_a=='u' .or. uplo_a=='U') a_upper = .true.
    if (uplo_a=='l' .or. uplo_a=='L') a_lower = .true.
  else
    if (uplo_a=='u' .or. uplo_a=='U' .or. uplo_a=='l' .or. uplo_a=='L') then
      write(error_unit,*) "elpa_hermitian_multiply warning: multiply_at_a = 1, so uplo_a is ignored."
    endif
  endif
  if (uplo_c=='u' .or. uplo_c=='U') c_upper = .true.
  if (uplo_c=='l' .or. uplo_c=='L') c_lower = .true.

  if (wantDebug .and. myid==0) print *, "elpa_hermitian_multiply: uplo_a=", uplo_a, ", uplo_c=", uplo_c

  if (useGPU) then
    if (wantDebug) call obj%timer%start("gpu_malloc")
    num = l_rows*nblk*size_of_datatype
    successGPU = gpu_malloc(aux_bc_dev, num)
    check_alloc_gpu("elpa_hermitian_multiply: aux_bc_dev", successGPU)
    if (wantDebug) call obj%timer%stop("gpu_malloc")

#if !defined(DEVICE_POINTER)
    if (wantDebug) call obj%timer%start("gpu_malloc")
    num = matrixRows*matrixCols*size_of_datatype
    successGPU = gpu_malloc(a_dev, num)
    check_alloc_gpu("elpa_hermitian_multiply: a_dev", successGPU)
    if (wantDebug) call obj%timer%stop("gpu_malloc")

    call obj%timer%start("gpu_memcpy")
#ifdef WITH_GPU_STREAMS
    call gpu_memcpy_async_and_stream_synchronize &
    ("elpa_hermitian_multiply: a to a_dev", a_dev, 0_c_intptr_t, &
                                       a(1:matrixRows,1:matrixCols), &
                                       1, 1, num, gpuMemcpyHostToDevice, my_stream, .false., .true., .false.)
#else
    successGPU = gpu_memcpy(a_dev, int(loc(a),kind=c_intptr_t), num, gpuMemcpyHostToDevice)
    check_memcpy_gpu("elpa_hermitian_multiply: a to a_dev", successGPU)
#endif
    call obj%timer%stop("gpu_memcpy")
#endif /* DEVICE_POINTER */
  endif !useGPU

! _________________________________________________________________________________________________________________________________

  ! main loop: build up the result matrix by processor rows
  call obj%timer%start("main_loop")
  do np = 0, np_rows-1

#ifdef WITH_NVTX
    call nvtxRangePush("do np = 0, np_rows-1")
#endif

    ! In this turn, procs of row np assemble the result

    l_rows_np = local_index(na, np, np_rows, nblk, -1) ! local rows on receiving processors

    nr_done = 0 ! Number of rows done
    nstor = 0   ! Number of columns stored in aux_mat

    if (useGPU) then
      num = l_rows*nblk_mult*size_of_datatype
#ifdef WITH_GPU_STREAMS
      successGPU = gpu_memset_async(aux_mat_dev, 0, num, my_stream)
      check_memcpy_gpu("multiply: aux_mat_dev", successGPU)
#else
      successGPU = gpu_memset(aux_mat_dev, 0, num)
      check_memcpy_gpu("multiply: aux_mat_dev", successGPU)
#endif
    else ! useGPU
      aux_mat = 0
    endif ! useGPU

    ! Loop over the blocks on row np; nb is the 0-based local index of the block
    do nb = 0, (l_rows_np-1)/nblk
#ifdef WITH_NVTX
      call nvtxRangePush("do nb = 0, (l_rows_np-1)/nblk")
#endif

      goff  = nb*np_rows + np ! offset in the global grid of blocks
      
      ! Get the processor column which owns this block
      ! and the offset in blocks within this column.
      ! The corresponding block column in A is then broadcast to all for multiplication with B

      np_bc = MOD(goff, np_cols) ! np, that posesses the given column of blocks; trans_a='T'; "bc"=block column; rename: np_bc -> np_col_b / np_col_curr
      
      noff = goff/np_cols   ! offset in the local grid of blocks
      
      ! Gather up the complete column/row of blocks of A (for T/N case) on the owner in contigous memory of aux_bc array
      ! if not for upper/lower cases: aux_bc_2D(1:l_rows,1:l_cols) = a(1:l_rows,1:l_cols)
      n_aux_bc = 0
      if (useGPU) then
        ! dry run
        do n = 1, min(nblk, l_rows_np-nb*nblk) ! Loop over local columns for the broadcast
          gcol = goff*nblk + n ! global column corresponding to n, needed only for a_lower and a_upper cases
          if (nstor==0 .and. n==1) gcol_min = gcol

          lrs = 1       ! 1st (start) local row number for broadcast
          lre = l_rows  ! last (end)  local row number for broadcast
          if (a_lower) lrs = local_index(gcol, my_prow, np_rows, nblk, +1)
          if (a_upper) lre = local_index(gcol, my_prow, np_rows, nblk, -1)
          
          lrs_save(n) = lrs
          lre_save(n) = lre

          if (lrs <= lre) then
            nvals = lre-lrs+1
            n_aux_bc_save(n) = n_aux_bc
            n_aux_bc = n_aux_bc + nvals
          endif ! (lrs <= lre)
        enddo ! n = 1, min(nblk, l_rows_np-nb*nblk)

        if (my_pcol == np_bc) then
          if (wantDebug) call obj%timer%start("gpu_memcpy")
          num = min(nblk, l_rows_np-nb*nblk)*size_of_int
#ifdef WITH_GPU_STREAMS
          successGPU = gpu_memcpy_async(lrs_save_dev, int(loc(lrs_save),kind=c_intptr_t), num, gpuMemcpyHostToDevice, my_stream)
          successGPU = gpu_memcpy_async(lre_save_dev, int(loc(lre_save),kind=c_intptr_t), num, gpuMemcpyHostToDevice, my_stream)
          successGPU = gpu_memcpy_async(n_aux_bc_save_dev, int(loc(n_aux_bc_save),kind=c_intptr_t), &
                                                                                          num, gpuMemcpyHostToDevice, my_stream)
          if (wantDebug) successGPU = gpu_stream_synchronize(my_stream)
#else
          successGPU = gpu_memcpy      (lrs_save_dev, int(loc(lrs_save),kind=c_intptr_t), num, gpuMemcpyHostToDevice)
          successGPU = gpu_memcpy      (lre_save_dev, int(loc(lre_save),kind=c_intptr_t), num, gpuMemcpyHostToDevice)
          successGPU = gpu_memcpy      (n_aux_bc_save_dev, int(loc(n_aux_bc_save),kind=c_intptr_t), num, gpuMemcpyHostToDevice)
#endif
          check_memcpy_gpu("elpa_hermitian_multiply: n_aux_bc_save to n_aux_bc_save_dev 1", successGPU)
          if (wantDebug) call obj%timer%stop("gpu_memcpy")

          if (wantDebug) call obj%timer%start("gpu_copy_a_aux_bc_loop_kernel")
          call gpu_copy_a_aux_bc_loop(PRECISION_CHAR, a_dev, aux_bc_dev, lrs_save_dev, lre_save_dev, n_aux_bc_save_dev, &
                                      noff, nblk, matrixRows, min(nblk, l_rows_np-nb*nblk), debug, my_stream)
          if (wantDebug) call obj%timer%stop("gpu_copy_a_aux_bc_loop_kernel")
        endif
        
      else ! useGPU
        if (wantDebug) call obj%timer%start("loop_copy_a_aux_bc")
        do n = 1, min(nblk, l_rows_np-nb*nblk) ! Loop over local columns for the broadcast

          gcol = goff*nblk + n ! global column corresponding to n, needed only for a_lower and a_upper cases
          if (nstor==0 .and. n==1) gcol_min = gcol

          lrs = 1       ! 1st (start) local row number for broadcast
          lre = l_rows  ! last (end)  local row number for broadcast
          if (a_lower) lrs = local_index(gcol, my_prow, np_rows, nblk, +1)
          if (a_upper) lre = local_index(gcol, my_prow, np_rows, nblk, -1)
          
          lrs_save(n) = lrs
          lre_save(n) = lre

          if (lrs <= lre) then
            nvals = lre-lrs+1

            if (my_pcol == np_bc) aux_bc(n_aux_bc+1:n_aux_bc+nvals) = a(lrs:lre,noff*nblk+n)
            n_aux_bc = n_aux_bc + nvals

          endif ! (lrs <= lre)
        enddo ! n = 1, min(nblk, l_rows_np-nb*nblk)
        if (wantDebug) call obj%timer%stop("loop_copy_a_aux_bc")
      endif ! useGPU

#ifdef WITH_MPI
      ! copy data to host for bcast, if needed
      if (useGPU .and. .not. useCCL) then
        if (wantDebug) call obj%timer%start("gpu_memcpy")
        num = l_rows*nblk*size_of_datatype
#ifdef WITH_GPU_STREAMS
        successGPU = gpu_memcpy_async(int(loc(aux_bc),kind=c_intptr_t), aux_bc_dev, num, gpuMemcpyDeviceToHost, my_stream)
        successGPU = gpu_stream_synchronize(my_stream)
#else
        successGPU = gpu_memcpy      (int(loc(aux_bc),kind=c_intptr_t), aux_bc_dev, num, gpuMemcpyDeviceToHost)
#endif
        check_memcpy_gpu("elpa_hermitian_multiply: aux_bc_dev -> aux_bc", successGPU)
        if (wantDebug) call obj%timer%stop("gpu_memcpy")
      endif ! useGPU  .and. .not. useCCL

      ! Broadcast block column
      if (useCCL) then
#ifdef USE_CCL_HERMITIAN_MULTIPLY
#ifdef WITH_NVTX
        call nvtxRangePush("ccl_bcast aux_bc_dev")
#endif      
        call obj%timer%start("ccl_bcast")

        ccl_comm_cols = obj%gpu_setup%ccl_comm_cols

        successGPU = ccl_bcast(aux_bc_dev, aux_bc_dev, int(k_datatype*n_aux_bc,kind=c_size_t), cclDatatype, &
                              int(np_bc,kind=c_int), ccl_comm_cols, my_stream)

        if (.not. successGPU) then
          print *,"Error in ccl_bcast"
          stop 1
        endif

        successGPU = gpu_stream_synchronize(my_stream)
        check_stream_synchronize_gpu("elpa_cholesky: ccl_bcast", successGPU)

        call obj%timer%stop("ccl_bcast")
#ifdef WITH_NVTX
        call nvtxRangePop() ! ccl_bcast aux_bc_dev
#endif
#endif /* USE_CCL_HERMITIAN_MULTIPLY */
      else ! useCCL

        if (wantDebug) then
          call obj%timer%start("mpi_barrier_before_bcast")
          call MPI_Barrier(int(mpi_comm_cols,kind=MPI_KIND), mpierr)
          call obj%timer%stop("mpi_barrier_before_bcast")
        endif

        call obj%timer%start("mpi_bcast")

        call MPI_Bcast(aux_bc, int(n_aux_bc,kind=MPI_KIND), MPI_MATH_DATATYPE_PRECISION, &
                      int(np_bc,kind=MPI_KIND), int(mpi_comm_cols,kind=MPI_KIND), mpierr)

        call obj%timer%stop("mpi_bcast")
      endif ! useCCL


      ! copy data back to device, if needed
      if (useGPU .and. .not. useCCL) then
        if (wantDebug) call obj%timer%start("gpu_memcpy")
        num = l_rows*nblk*size_of_datatype
#ifdef WITH_GPU_STREAMS
        successGPU = gpu_memcpy_async(aux_bc_dev, int(loc(aux_bc),kind=c_intptr_t), num, gpuMemcpyHostToDevice, my_stream)
        if (wantDebug) successGPU = gpu_stream_synchronize(my_stream)
#else
        successGPU = gpu_memcpy      (aux_bc_dev, int(loc(aux_bc),kind=c_intptr_t), num, gpuMemcpyHostToDevice)
#endif
        check_memcpy_gpu("elpa_hermitian_multiply: aux_bc -> aux_bc_dev", successGPU)
        if (wantDebug) call obj%timer%stop("gpu_memcpy")
      endif ! useGPU .and. .not. useCCL
#endif /* WITH_MPI */


      ! Copy what we got in aux_mat
      if (wantDebug) call obj%timer%start("loop_copy_aux_bc_aux_mat")
      if (useGPU) then
        nstor0 = nstor+1
        nstor  = nstor + min(nblk, l_rows_np-nb*nblk)

        if (wantDebug) call obj%timer%start("gpu_memcpy")
        num = min(nblk, l_rows_np-nb*nblk)*size_of_int
#ifdef WITH_GPU_STREAMS
        successGPU = gpu_memcpy_async(lrs_save_dev, int(loc(lrs_save),kind=c_intptr_t), num, gpuMemcpyHostToDevice, my_stream)
        successGPU = gpu_memcpy_async(lre_save_dev, int(loc(lre_save),kind=c_intptr_t), num, gpuMemcpyHostToDevice, my_stream)
        successGPU = gpu_memcpy_async(n_aux_bc_save_dev, int(loc(n_aux_bc_save),kind=c_intptr_t), &
                                                                                        num, gpuMemcpyHostToDevice, my_stream)
        if (wantDebug) successGPU = gpu_stream_synchronize(my_stream)
#else
        successGPU = gpu_memcpy      (lrs_save_dev, int(loc(lrs_save),kind=c_intptr_t), num, gpuMemcpyHostToDevice)
        successGPU = gpu_memcpy      (lre_save_dev, int(loc(lre_save),kind=c_intptr_t), num, gpuMemcpyHostToDevice)
        successGPU = gpu_memcpy      (n_aux_bc_save_dev, int(loc(n_aux_bc_save),kind=c_intptr_t), num, gpuMemcpyHostToDevice)
#endif     
        check_memcpy_gpu("elpa_hermitian_multiply: n_aux_bc_save to n_aux_bc_save_dev 2", successGPU)
        if (wantDebug) call obj%timer%stop("gpu_memcpy")

        if (wantDebug) call obj%timer%start("gpu_copy_aux_bc_aux_mat_loop_kernel")
        call gpu_copy_aux_bc_aux_mat_loop(PRECISION_CHAR, aux_bc_dev, aux_mat_dev, lrs_save_dev, lre_save_dev, n_aux_bc_save_dev, &
                                          nstor0, l_rows, min(nblk, l_rows_np-nb*nblk), debug, my_stream)
        if (wantDebug) call obj%timer%stop("gpu_copy_aux_bc_aux_mat_loop_kernel")
      else ! useGPU
        n_aux_bc = 0
        do n = 1, min(nblk, l_rows_np-nb*nblk)
          nstor = nstor+1
          lrs = lrs_save(n)
          lre = lre_save(n)
          if (lrs<=lre) then
            nvals = lre-lrs+1
            aux_mat(lrs:lre,nstor) = aux_bc(n_aux_bc+1:n_aux_bc+nvals)
            n_aux_bc = n_aux_bc + nvals
          endif
        enddo
      endif ! useGPU
      if (wantDebug) call obj%timer%stop("loop_copy_aux_bc_aux_mat")

      ! If we got nblk_mult columns in aux_mat or this is the last block
      ! do the matrix multiplication

      if (nstor==nblk_mult .or. nb*nblk+nblk >= l_rows_np) then

        lrs = 1       ! 1st local row number for multiply
        lre = l_rows  ! last local row number for multiply
        if (a_lower) lrs = local_index(gcol_min, my_prow, np_rows, nblk, +1)
        if (a_upper) lre = local_index(gcol, my_prow, np_rows, nblk, -1)

        lcs = 1       ! 1st local col number for multiply
        lce = l_cols  ! last local col number for multiply
        if (c_upper) lcs = local_index(gcol_min, my_pcol, np_cols, nblk, +1)
        if (c_lower) lce = MIN(local_index(gcol, my_pcol, np_cols, nblk, -1),l_cols)

        if (lcs <= lce) then
          if (lrs <= lre) then
            if (useGPU) then
              aux_off = (lrs-1)*size_of_datatype
              if (multiply_at_a == 0) then ! C = A^T * B
                b_off = ((lcs-1)*ldb+lrs-1)*size_of_datatype
              else ! C = A^T * A
                a_off = ((lcs-1)*matrixRows+lrs-1)*size_of_datatype
              endif

              NVTX_RANGE_PUSH("gpublas")
              call obj%timer%start("gpublas")
              gpuHandle = obj%gpu_setup%gpublasHandleArray(0)
              if (multiply_at_a == 0) then ! C = A^T * B
                b_off = ((lcs-1)*ldb+lrs-1)*size_of_datatype

                ! tmp1_dev = aux_mat_dev^{T/N} * b_dev
                call gpublas_PRECISION_GEMM(BLAS_TRANS_OR_CONJ, 'N', nstor, lce-lcs+1, lre-lrs+1, ONE, &
                                            aux_mat_dev+aux_off, l_rows, &
                                            b_dev+b_off, ldb, ZERO, &
                                            tmp1_dev, nstor, gpuHandle)
              else ! C = A^T * A
                a_off = ((lcs-1)*matrixRows+lrs-1)*size_of_datatype
                
                ! tmp1_dev = aux_mat_dev^{T/N} * a_dev
                call gpublas_PRECISION_GEMM(BLAS_TRANS_OR_CONJ, 'N', nstor, lce-lcs+1, lre-lrs+1, ONE, &
                                            aux_mat_dev+aux_off, l_rows, &
                                            a_dev+a_off, matrixRows, ZERO, &
                                            tmp1_dev, nstor, gpuHandle)
              endif
              if (wantDebug) successGPU = gpu_DeviceSynchronize()
              call obj%timer%stop("gpublas")
              NVTX_RANGE_POP("gpublas")
            else ! useGPU
              call obj%timer%start("blas")
              if (multiply_at_a == 0) then ! C = A^T * B
                ! tmp1 = aux_mat^T * b
                call PRECISION_GEMM(BLAS_TRANS_OR_CONJ, 'N', int(nstor,kind=BLAS_KIND), &
                                  int(lce-lcs+1,kind=BLAS_KIND), int(lre-lrs+1,kind=BLAS_KIND), ONE, &
                                  aux_mat(lrs:lre,1:nstor), int(lre-lrs+1,kind=BLAS_KIND), &
                                  b(lrs,lcs), int(ldb,kind=BLAS_KIND), ZERO, &
                                  tmp1, int(nstor,kind=BLAS_KIND))
              else
                ! tmp1 = aux_mat^T * a
                call PRECISION_GEMM(BLAS_TRANS_OR_CONJ, 'N', int(nstor,kind=BLAS_KIND), &
                                  int(lce-lcs+1,kind=BLAS_KIND), int(lre-lrs+1,kind=BLAS_KIND), ONE, &
                                  aux_mat(lrs:lre,1:nstor), int(lre-lrs+1,kind=BLAS_KIND), &
                                  a(lrs,lcs), int(matrixRows,kind=BLAS_KIND), ZERO, &
                                  tmp1, int(nstor,kind=BLAS_KIND))
              endif
              call obj%timer%stop("blas")
            endif ! useGPU
          else ! (lrs <= lre)
            if (useGPU) then
              num = nstor*(lce-lcs+1)*size_of_datatype
#ifdef WITH_GPU_STREAMS
              successGPU = gpu_memset_async(tmp1_dev, 0, num, my_stream)
              check_memcpy_gpu("multiply: tmp1_dev", successGPU)
#else
              successGPU = gpu_memset      (tmp1_dev, 0, num)
              check_memcpy_gpu("multiply: tmp1_dev", successGPU)
#endif
            else ! useGPU
              tmp1(1:nstor*(lce-lcs+1)) = 0
            endif ! useGPU
          endif ! (lrs <= lre)

          ! Sum up the results and send to processor row np

#ifdef WITH_MPI
          ! copy data to host, if needed
          if (useGPU .and. .not. useCCL) then
            if (wantDebug) call obj%timer%start("gpu_memcpy")
            num = nstor*(lce-lcs+1)*size_of_datatype
#ifdef WITH_GPU_STREAMS
            successGPU = gpu_memcpy_async(int(loc(tmp1),kind=c_intptr_t), tmp1_dev, num, gpuMemcpyDeviceToHost, my_stream)
            successGPU = gpu_stream_synchronize(my_stream)
#else
            successGPU = gpu_memcpy      (int(loc(tmp1),kind=c_intptr_t), tmp1_dev, num, gpuMemcpyDeviceToHost)
#endif
            check_memcpy_gpu("elpa_hermitian_multiply: tmp1_dev to tmp1", successGPU)
            if (wantDebug) call obj%timer%stop("gpu_memcpy")
          endif ! useGPU .and. .not. useCCL

          ! MPI/ccl Reduce
          if (useCCL) then
#ifdef USE_CCL_HERMITIAN_MULTIPLY
#ifdef WITH_NVTX
            call nvtxRangePush("ccl_reduce tmp1_dev")
#endif
            call obj%timer%start("ccl_reduce")
            ccl_comm_rows = obj%gpu_setup%ccl_comm_rows

            successGPU = ccl_reduce(tmp1_dev, tmp1_dev, int(k_datatype*nstor*(lce-lcs+1),kind=c_size_t), cclDataType, &
                                    cclSum, int(np,kind=c_int), ccl_comm_rows, my_stream)

            if (.not. successGPU) then
              print *,"Error in ccl_reduce"
              stop 1
            endif

            successGPU = gpu_stream_synchronize(my_stream)
            check_stream_synchronize_gpu("elpa_cholesky: ccl_reduce", successGPU)

            call obj%timer%stop("ccl_reduce")
#ifdef WITH_NVTX
            call nvtxRangePop() ! ccl_reduce tmp1_dev
#endif
#endif /* USE_CCL_HERMITIAN_MULTIPLY */
          else ! useCCL

            if (wantDebug) then
              call obj%timer%start("mpi_barrier_before_reduce")
              call MPI_Barrier(int(mpi_comm_rows,kind=MPI_KIND), mpierr)
              call obj%timer%stop("mpi_barrier_before_reduce")
            endif

            call obj%timer%start("mpi_reduce")
            if (my_prow==np) then
              call MPI_Reduce(MPI_IN_PLACE, tmp1, int(nstor*(lce-lcs+1),kind=MPI_KIND),  MPI_MATH_DATATYPE_PRECISION, &
                              MPI_SUM, int(np,kind=MPI_KIND), int(mpi_comm_rows,kind=MPI_KIND), mpierr)
            else
              call MPI_Reduce(tmp1, tmp1, int(nstor*(lce-lcs+1),kind=MPI_KIND),  MPI_MATH_DATATYPE_PRECISION, &
                              MPI_SUM, int(np,kind=MPI_KIND), int(mpi_comm_rows,kind=MPI_KIND), mpierr)
            endif
            call obj%timer%stop("mpi_reduce")
          endif ! useCCL

          ! copy data back to device, if needed. only my_prow==np copies data to c_dev
          if (useGPU .and. .not. useCCL .and. my_prow==np) then
            if (wantDebug) call obj%timer%start("gpu_memcpy")
            num = nstor*(lce-lcs+1)*size_of_datatype
#ifdef WITH_GPU_STREAMS
            successGPU = gpu_memcpy_async(tmp1_dev, int(loc(tmp1),kind=c_intptr_t), num, gpuMemcpyHostToDevice, my_stream)
            if (wantDebug) successGPU = gpu_stream_synchronize(my_stream)
#else
            successGPU = gpu_memcpy      (tmp1_dev, int(loc(tmp1),kind=c_intptr_t), num, gpuMemcpyHostToDevice)
#endif
            check_memcpy_gpu("elpa_hermitian_multiply: tmp1 to tmp1_dev", successGPU)
            if (wantDebug) call obj%timer%stop("gpu_memcpy")
          endif ! useGPU .and. .not. useCCL
#else /* WITH_MPI */

#endif /* WITH_MPI */

          ! Put the result into C
          if (wantDebug) call obj%timer%start("copy_tmp1_c")
          if (useGPU) then
            if (my_prow==np) call gpu_copy_tmp2_c(PRECISION_CHAR, tmp1_dev, &
                                                  c_dev, nr_done, nstor, lcs, lce, ldc, ldcCols, debug, my_stream)
          else ! useGPU
            if (my_prow==np) then
              call c_f_pointer(c_loc(tmp1(1)), tmp2d, [nstor, lce-lcs+1])

              c(nr_done+1:nr_done+nstor,lcs:lce) = tmp2d
            endif
          endif ! useGPU
          if (wantDebug) call obj%timer%stop("copy_tmp1_c")
        endif ! (lcs <= lce)

        nr_done = nr_done+nstor
        nstor=0
        if (useGPU) then
          num = l_rows*nblk_mult*size_of_datatype
#ifdef WITH_GPU_STREAMS
          successGPU = gpu_memset_async(aux_mat_dev, 0, num, my_stream)
          check_memcpy_gpu("multiply: aux_mat_dev", successGPU)
#else
          successGPU = gpu_memset(aux_mat_dev, 0, num)
          check_memcpy_gpu("multiply: aux_mat_dev", successGPU)
#endif
        else ! useGPU
          aux_mat(:,:) = 0
        endif ! useGPU
      endif ! (nstor==nblk_mult .or. nb*nblk+nblk >= l_rows_np)
    
#ifdef WITH_NVTX
      call nvtxRangePop() ! do nb = 0, (l_rows_np-1)/nblk
#endif
    enddo ! nb = 0, (l_rows_np-1)/nblk

#ifdef WITH_NVTX
    call nvtxRangePop() ! do np = 0, np_rows-1
#endif
  enddo ! main loop: np = 0, np_rows-1
  call obj%timer%stop("main_loop")
  
!_______________________________________________

  if (useGPU) then
#if !defined(DEVICE_POINTER)
    ! copy result c_dev back to CPU
    call obj%timer%start("gpu_memcpy")
    num = ldc*ldcCols*size_of_datatype
#ifdef WITH_GPU_STREAMS
    check_stream_synchronize_gpu("elpa_hermitian_multiply: c_dev -> c", successGPU)
    call gpu_memcpy_async_and_stream_synchronize &
        ("elpa_hermitian_multiply: c_dev to c", c_dev, 0_c_intptr_t, c(1:ldc,1:ldcCols), &
          1, 1, num, gpuMemcpyDeviceToHost, my_stream, .false., .true., .false.)
#else
    successGPU = gpu_memcpy(int(loc(c),kind=c_intptr_t), c_dev, num, gpuMemcpyDeviceToHost)
    check_memcpy_gpu("elpa_hermitian_multiply: c_dev -> c", successGPU)
#endif
    call obj%timer%stop("gpu_memcpy")
#endif /* !defined(DEVICE_POINTER) */
  endif ! useGPU


!______________________________________________________________________________________________

  if (useGPU) then
    if (wantDebug) call obj%timer%start("gpu_free")
#if !defined(DEVICE_POINTER)
    if (multiply_at_a == 0) then ! C = A^T * B
      successGPU = gpu_free(b_dev)
      check_dealloc_gpu("elpa_hermitian_multiply: b_dev", successGPU)
    endif ! (multiply_at_a == 0)

    successGPU = gpu_free(c_dev)
    check_dealloc_gpu("elpa_hermitian_multiply: c_dev", successGPU)

#else /* DEVICE_POINTER */

#endif /* DEVICE_POINTER */

    if (.not. useCCL) then
#if !defined(WITH_OPENMP_OFFLOAD_GPU_VERSION) && !defined(WITH_SYCL_GPU_VERSION)
      successGPU = gpu_host_unregister(int(loc(aux_bc),kind=c_intptr_t))
      check_host_unregister_gpu("elpa_hermitian_multiply: aux_bc", successGPU)
#endif
    endif

#if !defined(WITH_OPENMP_OFFLOAD_GPU_VERSION) && !defined(WITH_SYCL_GPU_VERSION)
    nullify(aux_mat)
    !nullify(tmp1)

    successGPU = gpu_free_host(aux_host)
    check_host_dealloc_gpu("elpa_hermitian_multiply: aux_host", successGPU)
#else
    deallocate(aux_mat, stat=istat, errmsg=errorMessage)
    check_deallocate("elpa_hermitian_multiply: aux_mat", istat, errorMessage)
#endif

    successGPU = gpu_free(aux_mat_dev)
    check_dealloc_gpu("elpa_hermitian_multiply: aux_mat_dev", successGPU)

    successGPU = gpu_free(tmp1_dev)
    check_dealloc_gpu("elpa_hermitian_multiply: tmp1_dev", successGPU)

    successGPU = gpu_free(aux_bc_dev)
    check_dealloc_gpu("elpa_hermitian_multiply: aux_bc_dev", successGPU)

    successGPU = gpu_free(lrs_save_dev)
    check_dealloc_gpu("elpa_hermitian_multiply: lrs_save_dev", successGPU)

    successGPU = gpu_free(lre_save_dev)
    check_dealloc_gpu("elpa_hermitian_multiply: lre_save_dev", successGPU)

    successGPU = gpu_free(n_aux_bc_save_dev)
    check_dealloc_gpu("elpa_hermitian_multiply: n_aux_bc_save_dev", successGPU)

#if !defined(DEVICE_POINTER)
    successGPU = gpu_free(a_dev)
    check_dealloc_gpu("elpa_hermitian_multiply: a_dev", successGPU)
#else
    !successGPU = gpu_free(a_dev)
    !check_dealloc_gpu("elpa_hermitian_multiply: a_dev", successGPU)
#endif
    if (wantDebug) call obj%timer%stop("gpu_free")
  else ! useGPU
    deallocate(aux_mat, stat=istat, errmsg=errorMessage)
    check_deallocate("elpa_hermitian_multiply: aux_mat", istat, errorMessage)
  endif ! useGPU

  if (wantDebug) call obj%timer%start("deallocate")
  deallocate(aux_bc, lrs_save, lre_save, n_aux_bc_save, stat=istat, errmsg=errorMessage)
  check_deallocate("elpa_hermitian_multiply: aux_bc, lrs_save, lre_save", istat, errorMessage)
  
  if (.not. useCCL) then
      if (useGPU) then
#if !defined(WITH_OPENMP_OFFLOAD_GPU_VERSION) && !defined(WITH_SYCL_GPU_VERSION)
        successGPU = gpu_host_unregister(int(loc(tmp1),kind=c_intptr_t))
        check_host_unregister_gpu("elpa_hermitian_multiply: tmp1", successGPU)
#endif
      endif

    deallocate(tmp1, stat=istat, errmsg=errorMessage)
    call check_alloc("elpa_hermitian_multiply", "tmp1", istat, errorMessage)

    nullify(tmp2d)
  endif
  if (wantDebug) call obj%timer%stop("deallocate")

  call obj%timer%stop("elpa_hermitian_multiply_&
  &MATH_DATATYPE&
  &_&
  &PRECISION&
  &"//gpuString)

#ifdef WITH_NVTX
  call nvtxRangePop() ! multiply
#endif
