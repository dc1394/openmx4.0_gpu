#ifndef ELPA_H
#define ELPA_H

#include <limits.h>

#ifdef __cplusplus
#include <complex>
#else
#include <complex.h>
#endif

#include <elpa/elpa_version.h>

struct elpa_struct;
typedef struct elpa_struct *elpa_t;

struct elpa_autotune_struct;
typedef struct elpa_autotune_struct *elpa_autotune_t;


#include <elpa/elpa_constants.h>
#include <elpa/elpa_generated_c_api.h>
#include <elpa/elpa_generated.h>
#include <elpa/elpa_generic.h>
#include <elpa/elpa_explicit_name.h>

#define ELPA_2STAGE_REAL_GPU    ELPA_2STAGE_REAL_NVIDIA_GPU
#define ELPA_2STAGE_COMPLEX_GPU ELPA_2STAGE_COMPLEX_NVIDIA_GPU

#ifdef __cplusplus
extern "C"
#endif
const char *elpa_strerr(int elpa_error);

#endif
