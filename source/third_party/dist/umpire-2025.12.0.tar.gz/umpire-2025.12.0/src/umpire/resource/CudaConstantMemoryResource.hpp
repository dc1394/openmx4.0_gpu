//////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2016-25, Lawrence Livermore National Security, LLC and Umpire
// project contributors. See the COPYRIGHT file for details.
//
// SPDX-License-Identifier: (MIT)
//////////////////////////////////////////////////////////////////////////////
#ifndef UMPIRE_CudaConstantMemoryResource_HPP
#define UMPIRE_CudaConstantMemoryResource_HPP

#include <cuda_runtime_api.h>

#include <mutex>

#include "umpire/resource/MemoryResource.hpp"
#include "umpire/util/AllocationRecord.hpp"
#include "umpire/util/Platform.hpp"

namespace umpire {
namespace resource {

class CudaConstantMemoryResource : public MemoryResource {
 public:
  CudaConstantMemoryResource(const std::string& name, int id, MemoryResourceTraits traits);

  void* allocate(std::size_t bytes);
  void deallocate(void* ptr, std::size_t bytes);

  bool isAccessibleFrom(Platform p) noexcept;
  Platform getPlatform() noexcept;

 private:
  std::size_t m_current_size;
  std::size_t m_highwatermark;

  Platform m_platform;

  std::size_t m_offset;
  void* m_ptr;

  bool m_initialized;
  std::mutex m_mutex;
};

} // end of namespace resource
} // end of namespace umpire

#endif // UMPIRE_CudaConstantMemoryResource_HPP
