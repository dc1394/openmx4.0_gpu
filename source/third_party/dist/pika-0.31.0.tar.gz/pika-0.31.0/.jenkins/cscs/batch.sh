#!/bin/bash -l

# Copyright (c) 2020 ETH Zurich
#
# SPDX-License-Identifier: BSL-1.0
# Distributed under the Boost Software License, Version 1.0. (See accompanying
# file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

set -eux

orig_src_dir="$(pwd)"
src_dir="/dev/shm/pika/src"
build_dir="/dev/shm/pika/build"
install_dir="/dev/shm/pika/install"

# Copy source directory to /dev/shm for faster builds
mkdir -p "${build_dir}"
cp -r "${orig_src_dir}" "${src_dir}"

source "${src_dir}/.jenkins/cscs/env-common.sh"
source "${src_dir}/.jenkins/cscs/env-${configuration_name}.sh"

set +e
spack build-env ${spack_spec} -- ctest \
    --verbose \
    -S ${src_dir}/.jenkins/cscs/ctest.cmake \
    -DCTEST_BUILD_EXTRA_OPTIONS="${build_extra_options:-}" \
    -DCTEST_TEST_EXTRA_OPTIONS="${test_extra_options:-}" \
    -DCTEST_CONFIGURE_EXTRA_OPTIONS="${configure_extra_options} -DCMAKE_INSTALL_PREFIX=${install_dir}" \
    -DCTEST_BUILD_CONFIGURATION_NAME="${configuration_name_with_build_type}" \
    -DCTEST_SOURCE_DIRECTORY="${src_dir}" \
    -DCTEST_BINARY_DIRECTORY="${build_dir}"
set -e

ctest_exit_code=$? # /!\ Should be positioned right after the ctest command
# Things went wrong by default
file_errors=1
configure_errors=1
build_errors=1
test_errors=1

# Copy the testing directory for saving as an artifact
cp -r "${build_dir}/Testing" "${orig_src_dir}/${configuration_name_with_build_type}-Testing"

if [[ -f "${build_dir}/Testing/TAG" ]]; then
    file_errors=0
    tag="$(head -n 1 ${build_dir}/Testing/TAG)"

    if [[ -f "${build_dir}/Testing/${tag}/Configure.xml" ]]; then
        configure_errors=$(grep '<Error>' "${build_dir}/Testing/${tag}/Configure.xml" | wc -l)
    fi

    if [[ -f "${build_dir}/Testing/${tag}/Build.xml" ]]; then
        build_errors=$(grep '<Error>' "${build_dir}/Testing/${tag}/Build.xml" | wc -l)
    fi

    if [[ -f "${build_dir}/Testing/${tag}/Test.xml" ]]; then
        test_errors=$(grep '<Test Status=\"failed\">' "${build_dir}/Testing/${tag}/Test.xml" | wc -l)
    fi
fi
ctest_status=$((ctest_exit_code + file_errors + configure_errors + build_errors + test_errors))

echo "${ctest_status}" >"jenkins-pika-${configuration_name_with_build_type}-ctest-status.txt"
exit $ctest_status
