var group__tbsm =
[
    [ "slate::tbsm", "group__tbsm.html#ga61621f986028d6ea636c2c4ec9137c97", null ],
    [ "slate::tbsm", "group__tbsm.html#gafb1ab70736e3e6e6a379217c6d3d3d55", null ]
];