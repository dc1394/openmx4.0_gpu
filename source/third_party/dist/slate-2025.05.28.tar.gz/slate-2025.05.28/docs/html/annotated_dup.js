var annotated_dup =
[
    [ "slate", "namespaceslate.html", [
      [ "device", "namespaceslate_1_1device.html", [
        [ "nx_traits", "structslate_1_1device_1_1nx__traits.html", null ]
      ] ],
      [ "internal", "namespaceslate_1_1internal.html", [
        [ "Array2D", "classslate_1_1internal_1_1_array2_d.html", "classslate_1_1internal_1_1_array2_d" ],
        [ "device_regions_params", "structslate_1_1internal_1_1device__regions__params.html", null ],
        [ "DevVector", "classslate_1_1internal_1_1_dev_vector.html", "classslate_1_1internal_1_1_dev_vector" ],
        [ "TargetType", "classslate_1_1internal_1_1_target_type.html", null ]
      ] ],
      [ "scalapack_api", null, [
        [ "IBConfig", "classslate_1_1scalapack__api_1_1_i_b_config.html", "classslate_1_1scalapack__api_1_1_i_b_config" ],
        [ "LookaheadConfig", "classslate_1_1scalapack__api_1_1_lookahead_config.html", "classslate_1_1scalapack__api_1_1_lookahead_config" ],
        [ "PanelThreadsConfig", "classslate_1_1scalapack__api_1_1_panel_threads_config.html", "classslate_1_1scalapack__api_1_1_panel_threads_config" ],
        [ "TargetConfig", "classslate_1_1scalapack__api_1_1_target_config.html", "classslate_1_1scalapack__api_1_1_target_config" ],
        [ "VerboseConfig", "classslate_1_1scalapack__api_1_1_verbose_config.html", "classslate_1_1scalapack__api_1_1_verbose_config" ]
      ] ],
      [ "BandMatrix", "classslate_1_1_band_matrix.html", "classslate_1_1_band_matrix" ],
      [ "BaseBandMatrix", "classslate_1_1_base_band_matrix.html", "classslate_1_1_base_band_matrix" ],
      [ "BaseMatrix", "classslate_1_1_base_matrix.html", "classslate_1_1_base_matrix" ],
      [ "BaseTrapezoidMatrix", "classslate_1_1_base_trapezoid_matrix.html", "classslate_1_1_base_trapezoid_matrix" ],
      [ "BaseTriangularBandMatrix", "classslate_1_1_base_triangular_band_matrix.html", "classslate_1_1_base_triangular_band_matrix" ],
      [ "Debug", "classslate_1_1_debug.html", "classslate_1_1_debug" ],
      [ "Exception", "classslate_1_1_exception.html", "classslate_1_1_exception" ],
      [ "FalseConditionException", "classslate_1_1_false_condition_exception.html", null ],
      [ "HermitianBandMatrix", "classslate_1_1_hermitian_band_matrix.html", "classslate_1_1_hermitian_band_matrix" ],
      [ "HermitianMatrix", "classslate_1_1_hermitian_matrix.html", "classslate_1_1_hermitian_matrix" ],
      [ "is_complex", "structslate_1_1is__complex.html", null ],
      [ "LockGuard", "classslate_1_1_lock_guard.html", "classslate_1_1_lock_guard" ],
      [ "Matrix", "classslate_1_1_matrix.html", "classslate_1_1_matrix" ],
      [ "MatrixStorage", "classslate_1_1_matrix_storage.html", "classslate_1_1_matrix_storage" ],
      [ "Memory", "classslate_1_1_memory.html", "classslate_1_1_memory" ],
      [ "mpi_type", "classslate_1_1mpi__type.html", null ],
      [ "MpiException", "classslate_1_1_mpi_exception.html", null ],
      [ "NotImplemented", "classslate_1_1_not_implemented.html", null ],
      [ "OmpSetMaxActiveLevels", "classslate_1_1_omp_set_max_active_levels.html", "classslate_1_1_omp_set_max_active_levels" ],
      [ "OptionValue", "classslate_1_1_option_value.html", null ],
      [ "SymmetricMatrix", "classslate_1_1_symmetric_matrix.html", "classslate_1_1_symmetric_matrix" ],
      [ "Tile", "classslate_1_1_tile.html", "classslate_1_1_tile" ],
      [ "Timer", "classslate_1_1_timer.html", "classslate_1_1_timer" ],
      [ "TrapezoidMatrix", "classslate_1_1_trapezoid_matrix.html", "classslate_1_1_trapezoid_matrix" ],
      [ "TriangularBandMatrix", "classslate_1_1_triangular_band_matrix.html", "classslate_1_1_triangular_band_matrix" ],
      [ "TriangularMatrix", "classslate_1_1_triangular_matrix.html", "classslate_1_1_triangular_matrix" ],
      [ "TrueConditionException", "classslate_1_1_true_condition_exception.html", null ]
    ] ]
];