var group__gbsv =
[
    [ "slate::gbsv", "group__gbsv.html#ga97d56f464660932672fd696349cec8ef", null ]
];