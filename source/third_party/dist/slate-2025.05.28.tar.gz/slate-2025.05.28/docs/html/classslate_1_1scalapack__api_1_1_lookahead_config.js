var classslate_1_1scalapack__api_1_1_lookahead_config =
[
    [ "value", "classslate_1_1scalapack__api_1_1_lookahead_config.html#adc24e4420b3d2172299a36a26cb23192", null ],
    [ "value", "classslate_1_1scalapack__api_1_1_lookahead_config.html#a8cb45f3442bd653ca7ebc2a5a922eb66", null ]
];