var classslate_1_1scalapack__api_1_1_verbose_config =
[
    [ "value", "classslate_1_1scalapack__api_1_1_verbose_config.html#ab77297328eb4a0d4bedbe97fa7999577", null ],
    [ "value", "classslate_1_1scalapack__api_1_1_verbose_config.html#adb817f1459a0a35af6018d6a5f3278ff", null ]
];